export interface Empreendimento {
  id: string;
  nome: string;
  endereco?: string;
  created_at: string;
  updated_at: string;
}

export interface Lote {
  id: string;
  empreendimento_id?: string;
  quadra: string;
  numero: string;
  area_privativa?: number;
  status: 'vazio' | 'obra' | 'casa';
  created_at: string;
  updated_at: string;
  empreendimento?: Empreendimento;
  moradores?: Morador[];
}

export interface Morador {
  id: string;
  nome: string;
  cpf?: string;
  identidade?: string;
  telefone?: string;
  celular?: string;
  email?: string;
  cliente_status: 'Proprietário' | 'Inquilino' | 'Proprietário Morador' | 'Dependente';
  created_at: string;
  updated_at: string;
  lotes?: Lote[];
  veiculos?: Veiculo[];
}

export interface Veiculo {
  id: string;
  marca?: string;
  modelo?: string;
  cor?: string;
  placa: string;
  created_at: string;
  updated_at: string;
  moradores?: Morador[];
}

export interface Visitante {
  id: string;
  nome: string;
  documento: string;
  tipo_documento: 'CPF' | 'RG';
  telefone?: string;
  classificacao: 'Visitante' | 'Entregador' | 'Prestador de serviço' | 'Corretor de imóveis' | 'Outros';
  autorizado: boolean;
  creci?: string;
  tipo_servico?: string;
  lote_id?: string;
  veiculo?: string;
  veiculo_cor?: string;
  veiculo_placa?: string;
  data_entrada: string;
  data_saida?: string;
  created_at: string;
  updated_at: string;
  lote?: Lote;
}

export interface DashboardStats {
  moradores: number;
  lotes: number;
  veiculos: number;
  visitantesPresentes: number;
}

export interface ImportData {
  empreendimento?: string;
  quadra: string;
  lote: string;
  area_privativa?: number;
  cliente?: string;
  cliente_status?: string;
  telefone1?: string;
  telefone2?: string;
  telefone3?: string;
  email1?: string;
  email2?: string;
}
