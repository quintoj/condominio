import React from 'react';
import { ArrowDown, ArrowUp } from 'lucide-react';

interface SortableHeaderProps {
  label: string;
  sortKey: string;
  sortConfig: { key: string; direction: 'asc' | 'desc' } | null;
  onSort: (key: string) => void;
  className?: string;
  align?: 'left' | 'right';
}

export function SortableHeader({ label, sortKey, sortConfig, onSort, className, align = 'left' }: SortableHeaderProps) {
  const isSorted = sortConfig?.key === sortKey;
  const direction = sortConfig?.direction;

  return (
    <th
      className={`px-6 py-3 text-${align} text-xs font-medium text-gray-500 uppercase tracking-wider cursor-pointer hover:bg-gray-100 ${className}`}
      onClick={() => onSort(sortKey)}
    >
      <div className={`flex items-center ${align === 'right' ? 'justify-end' : ''}`}>
        <span>{label}</span>
        {isSorted && (
          <span className="ml-2">
            {direction === 'asc' ? <ArrowUp className="w-3 h-3" /> : <ArrowDown className="w-3 h-3" />}
          </span>
        )}
      </div>
    </th>
  );
}
