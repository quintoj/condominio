import React, { useState } from 'react';
import { Upload, Download, FileSpreadsheet, AlertTriangle, CheckCircle2, Trash2 } from 'lucide-react';
import { supabase } from '../../lib/supabase';
import { ImportData } from '../../types';

export function Importacao() {
  const [file, setFile] = useState<File | null>(null);
  const [loading, setLoading] = useState(false);
  const [isClearing, setIsClearing] = useState(false);
  const [ignoreValidation, setIgnoreValidation] = useState(false);
  const [importResults, setImportResults] = useState<{
    success: number;
    errors: string[];
  } | null>(null);

  const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const selectedFile = e.target.files?.[0];
    if (selectedFile) {
      setFile(selectedFile);
      setImportResults(null);
    }
  };

  const parseCSV = (text: string): ImportData[] => {
    const lines = text.split('\n').filter(line => line.trim());
    if (lines.length < 2) return [];

    const headerMapping: { [key: string]: keyof ImportData } = {
        'empreendimento': 'empreendimento',
        'quadra': 'quadra',
        'lote': 'lote',
        'area privativa': 'area_privativa',
        'areapriva': 'area_privativa',
        'área privativa': 'area_privativa',
        'cliente': 'cliente',
        'cliente status': 'cliente_status',
        'clientestatus': 'cliente_status',
        'telefone 1': 'telefone1',
        'telefone1': 'telefone1',
        'telefone 2': 'telefone2',
        'telefone2': 'telefone2',
        'telefone 3': 'telefone3',
        'telefone3': 'telefone3',
        'e-mail 1': 'email1',
        'email1': 'email1',
        'e-mail 2': 'email2',
        'email2': 'email2',
    };
    
    const headers = lines[0].split(',').map(h => h.trim().toLowerCase().replace(/"/g, ''));
    const data: ImportData[] = [];

    for (let i = 1; i < lines.length; i++) {
        const values = lines[i].split(',');
        const row: Partial<ImportData> = {};
        
        headers.forEach((header, index) => {
            if (index >= values.length) return;
            const mappedKey = headerMapping[header];
            if (!mappedKey) return;

            let value = values[index]?.trim().replace(/"/g, '') || '';

            switch (mappedKey) {
                case 'quadra':
                    row.quadra = value.replace(/QUADRA\s*/i, '').trim();
                    break;
                case 'lote':
                    row.lote = value.replace(/LT/i, '').trim();
                    break;
                case 'area_privativa':
                    row.area_privativa = value ? parseFloat(value.replace(',', '.')) : undefined;
                    break;
                case 'cliente_status':
                    row.cliente_status = value.toLowerCase() === 'indefinido' ? 'Proprietário' : value;
                    break;
                default:
                    (row as any)[mappedKey] = value === '-' ? '' : value;
            }
        });

        if (row.quadra && row.lote) {
            data.push(row as ImportData);
        }
    }
    return data;
  };

  const validateRow = (row: ImportData): string[] => {
    const errors: string[] = [];
    if (!row.quadra) errors.push('Quadra é obrigatória');
    if (!row.lote) errors.push('Lote é obrigatório');
    if (row.cliente_status && !['Proprietário', 'Inquilino', 'Proprietário Morador', 'Dependente'].includes(row.cliente_status)) errors.push(`Cliente Status inválido: ${row.cliente_status}`);
    if (row.email1 && !/\S+@\S+\.\S+/.test(row.email1)) errors.push('Email 1 inválido');
    if (row.email2 && !/\S+@\S+\.\S+/.test(row.email2)) errors.push('Email 2 inválido');
    return errors;
  };

  const handleImport = async () => {
    if (!file) return;
    setLoading(true);
    setImportResults(null);
    try {
      const text = await file.text();
      const data = parseCSV(text);
      if (data.length === 0) throw new Error('Nenhum dado válido encontrado no arquivo. Verifique o formato do CSV.');

      const errors: string[] = [];
      let successCount = 0;
      for (let i = 0; i < data.length; i++) {
        const row = data[i];
        const rowErrors = ignoreValidation ? [] : validateRow(row);
        if (rowErrors.length > 0) {
          errors.push(`Linha ${i + 2}: ${rowErrors.join(', ')}`);
          continue;
        }
        try {
          let empreendimentoId: string | null = null;
          if (row.empreendimento) {
            const { data: existingEmp } = await supabase.from('empreendimentos').select('id').ilike('nome', row.empreendimento).single();
            if (existingEmp) empreendimentoId = existingEmp.id;
            else {
              const { data: newEmp } = await supabase.from('empreendimentos').insert([{ nome: row.empreendimento }]).select('id').single();
              empreendimentoId = newEmp?.id || null;
            }
          }
          const loteData = { empreendimento_id: empreendimentoId, quadra: row.quadra, numero: row.lote, area_privativa: row.area_privativa, status: 'casa' as const };
          const { data: existingLote } = await supabase.from('lotes').select('id').eq('quadra', row.quadra).eq('numero', row.lote).maybeSingle();
          let loteId: string;
          if (existingLote) {
            await supabase.from('lotes').update(loteData).eq('id', existingLote.id);
            loteId = existingLote.id;
          } else {
            const { data: newLote, error: loteError } = await supabase.from('lotes').insert([loteData]).select('id').single();
            if (loteError) throw loteError;
            loteId = newLote!.id;
          }
          if (row.cliente && loteId) {
            const moradorData = { nome: row.cliente, cliente_status: row.cliente_status || 'Proprietário', telefone: row.telefone1 || row.telefone2 || row.telefone3, email: row.email1 || row.email2 };
            const { data: newMorador, error: moradorError } = await supabase.from('moradores').insert([moradorData]).select('id').single();
            if (moradorError) throw moradorError;
            if (newMorador) await supabase.from('morador_lote').insert([{ morador_id: newMorador.id, lote_id: loteId }]);
          }
          successCount++;
        } catch (error) {
          errors.push(`Linha ${i + 2}: ${error instanceof Error ? error.message : 'Erro desconhecido'}`);
        }
      }
      setImportResults({ success: successCount, errors });
    } catch (error) {
      setImportResults({ success: 0, errors: [error instanceof Error ? error.message : 'Erro desconhecido'] });
    } finally {
      setLoading(false);
    }
  };

  const downloadTemplate = () => {
    const template = `empreendimento,quadra,lote,area_privativa,cliente,cliente_status,telefone1,telefone2,telefone3,email1,email2\nResidencial Alpha,QUADRA A,LT01,"300,50",João Silva,Proprietário Morador,(11) 1234-5678,(11) 9876-5432,,joao@email.com,\nResidencial Beta,QUADRA B,LT02,250,Maria Santos,Inquilino,(11) 2345-6789,,,maria@email.com,maria.santos@work.com\n,QUADRA C,LT03,400,Pedro Oliveira,Proprietário,(11) 3456-7890,,,pedro@email.com,`;
    const blob = new Blob([template], { type: 'text/csv;charset=utf-8;' });
    const link = document.createElement('a');
    link.href = URL.createObjectURL(blob);
    link.download = 'template_importacao.csv';
    link.click();
  };

  const exportData = async () => {
    setLoading(true);
    try {
      const { data: lotes } = await supabase.from('lotes').select(`*, empreendimento:empreendimentos(nome), moradores:morador_lote(morador:moradores(*))`);
      if (!lotes) return;
      const csvRows = ['empreendimento,quadra,lote,area_privativa,cliente,cliente_status,telefone1,email1'];
      lotes.forEach(lote => {
        const empreendimento = lote.empreendimento?.nome || '';
        const morador = lote.moradores?.[0]?.morador;
        csvRows.push([empreendimento, lote.quadra, lote.numero, lote.area_privativa || '', morador?.nome || '', morador?.cliente_status || '', morador?.telefone || '', morador?.email || ''].join(','));
      });
      const csv = csvRows.join('\n');
      const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
      const link = document.createElement('a');
      link.href = URL.createObjectURL(blob);
      link.download = `dados_condominio_${new Date().toISOString().split('T')[0]}.csv`;
      link.click();
    } catch (error) {
      console.error('Erro ao exportar dados:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleClearData = async () => {
    const confirmation = prompt('Esta ação é irreversível e removerá TODOS os dados do sistema (exceto usuários).\nPara confirmar, digite "LIMPAR DADOS":');
    if (confirmation !== 'LIMPAR DADOS') {
      alert('Limpeza de dados cancelada.');
      return;
    }
    setIsClearing(true);
    try {
      await supabase.from('morador_lote').delete().neq('morador_id', '00000000-0000-0000-0000-000000000000');
      await supabase.from('morador_veiculo').delete().neq('morador_id', '00000000-0000-0000-0000-000000000000');
      await supabase.from('visitantes').delete().neq('id', '00000000-0000-0000-0000-000000000000');
      await supabase.from('moradores').delete().neq('id', '00000000-0000-0000-0000-000000000000');
      await supabase.from('veiculos').delete().neq('id', '00000000-0000-0000-0000-000000000000');
      await supabase.from('lotes').delete().neq('id', '00000000-0000-0000-0000-000000000000');
      await supabase.from('empreendimentos').delete().neq('id', '00000000-0000-0000-0000-000000000000');
      alert('Todos os dados foram limpos com sucesso.');
      window.location.reload();
    } catch (error) {
      alert(`Erro ao limpar dados: ${error instanceof Error ? error.message : 'Erro desconhecido'}`);
    } finally {
      setIsClearing(false);
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h1 className="text-2xl font-bold text-gray-900">Importação e Exportação</h1>
        <div className="flex space-x-3">
          <button onClick={downloadTemplate} className="flex items-center px-4 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700 transition-colors"><Download className="w-4 h-4 mr-2" />Template</button>
          <button onClick={exportData} disabled={loading} className="flex items-center px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 disabled:opacity-50 transition-colors"><Download className="w-4 h-4 mr-2" />Exportar</button>
          <button onClick={handleClearData} disabled={isClearing} className="flex items-center px-4 py-2 bg-red-600 text-white rounded-lg hover:bg-red-700 disabled:opacity-50 transition-colors"><Trash2 className="w-4 h-4 mr-2" />{isClearing ? 'Limpando...' : 'Limpar Dados'}</button>
        </div>
      </div>

      <div className="bg-white p-6 rounded-lg shadow-sm border border-gray-200">
        <h2 className="text-lg font-semibold text-gray-900 mb-4">Importar Dados da Planilha</h2>
        <div className="space-y-4">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">Arquivo CSV</label>
            <div className="border-2 border-dashed border-gray-300 rounded-lg p-6 text-center">
              <input type="file" accept=".csv" onChange={handleFileSelect} className="hidden" id="csv-upload" />
              <label htmlFor="csv-upload" className="cursor-pointer"><FileSpreadsheet className="w-12 h-12 text-gray-400 mx-auto mb-4" /><p className="text-sm text-gray-600">Clique para selecionar ou arraste um arquivo</p><p className="text-xs text-gray-500 mt-1">Apenas .csv</p></label>
            </div>
            {file && <p className="text-sm text-green-600 mt-2">Arquivo: {file.name}</p>}
          </div>
          <div className="flex items-center"><input type="checkbox" id="ignore-validation" checked={ignoreValidation} onChange={(e) => setIgnoreValidation(e.target.checked)} className="h-4 w-4 text-orange-600 focus:ring-orange-500 border-gray-300 rounded" /><label htmlFor="ignore-validation" className="ml-2 text-sm text-gray-900">Ignorar regras de validação</label></div>
          <button onClick={handleImport} disabled={!file || loading} className="flex items-center px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 disabled:opacity-50 disabled:cursor-not-allowed transition-colors"><Upload className="w-4 h-4 mr-2" />{loading ? 'Importando...' : 'Importar Dados'}</button>
        </div>
        <div className="mt-6 p-4 bg-blue-50 border border-blue-200 rounded-md"><h3 className="text-sm font-medium text-blue-900 mb-2">Formato do arquivo CSV:</h3><ul className="text-sm text-blue-800 space-y-1"><li>• <strong>empreendimento:</strong> Nome (opcional)</li><li>• <strong>quadra:</strong> Identificação (obrigatório)</li><li>• <strong>lote:</strong> Número (obrigatório)</li><li>• <strong>area_privativa:</strong> Área em m² (opcional)</li><li>• <strong>cliente:</strong> Nome do morador (opcional)</li><li>• <strong>cliente_status:</strong> Proprietário, Inquilino, Proprietário Morador ou Dependente</li><li>• <strong>telefone1, telefone2, telefone3:</strong> Contatos</li><li>• <strong>email1, email2:</strong> Contatos</li></ul></div>
      </div>

      {importResults && (
        <div className="bg-white p-6 rounded-lg shadow-sm border border-gray-200">
          <h3 className="text-lg font-semibold text-gray-900 mb-4">Resultados da Importação</h3>
          <div className="space-y-4">
            <div className="flex items-center text-green-600"><CheckCircle2 className="w-5 h-5 mr-2" /><span className="font-medium">{importResults.success} registros importados com sucesso</span></div>
            {importResults.errors.length > 0 && (
              <div>
                <div className="flex items-center text-red-600 mb-2"><AlertTriangle className="w-5 h-5 mr-2" /><span className="font-medium">{importResults.errors.length} erro(s) encontrado(s):</span></div>
                <div className="bg-red-50 border border-red-200 rounded-md p-3 max-h-48 overflow-y-auto">{importResults.errors.map((error, index) => <p key={index} className="text-sm text-red-700">{error}</p>)}</div>
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
}
