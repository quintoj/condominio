import React, { useState } from 'react';
import { Upload, Download, FileSpreadsheet, AlertTriangle, CheckCircle2, Trash2, DatabaseBackup } from 'lucide-react';
import { supabase } from '../../lib/supabase';
import { ImportData } from '../../types';

export function Manutencao() {
  const [file, setFile] = useState<File | null>(null);
  const [loading, setLoading] = useState(false);
  const [isClearing, setIsClearing] = useState(false);
  const [isBackingUp, setIsBackingUp] = useState(false);
  const [ignoreValidation, setIgnoreValidation] = useState(false);
  const [importResults, setImportResults] = useState<{ success: number; errors: string[] } | null>(null);

  const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const selectedFile = e.target.files?.[0];
    if (selectedFile) { setFile(selectedFile); setImportResults(null); }
  };

  const parseCSV = (text: string): ImportData[] => {
    const lines = text.split('\n').filter(line => line.trim());
    if (lines.length < 2) return [];
    const headerMapping: { [key: string]: keyof ImportData } = { 'empreendimento': 'empreendimento', 'quadra': 'quadra', 'lote': 'lote', 'area privativa': 'area_privativa', 'areapriva': 'area_privativa', 'área privativa': 'area_privativa', 'cliente': 'cliente', 'cliente status': 'cliente_status', 'clientestatus': 'cliente_status', 'telefone 1': 'telefone1', 'telefone1': 'telefone1', 'telefone 2': 'telefone2', 'telefone2': 'telefone2', 'telefone 3': 'telefone3', 'telefone3': 'telefone3', 'e-mail 1': 'email1', 'email1': 'email1', 'e-mail 2': 'email2', 'email2': 'email2' };
    const headers = lines[0].split(',').map(h => h.trim().toLowerCase().replace(/"/g, ''));
    const data: ImportData[] = [];
    for (let i = 1; i < lines.length; i++) {
        const values = lines[i].split(',');
        const row: Partial<ImportData> = {};
        headers.forEach((header, index) => {
            if (index >= values.length) return;
            const mappedKey = headerMapping[header];
            if (!mappedKey) return;
            let value = values[index]?.trim().replace(/"/g, '') || '';
            switch (mappedKey) {
                case 'quadra': row.quadra = value.replace(/QUADRA\s*/i, '').trim(); break;
                case 'lote': row.lote = value.replace(/LT/i, '').trim(); break;
                case 'area_privativa': row.area_privativa = value ? parseFloat(value.replace(',', '.')) : undefined; break;
                case 'cliente_status': row.cliente_status = value.toLowerCase() === 'indefinido' ? 'Proprietário' : value; break;
                default: (row as any)[mappedKey] = value === '-' ? '' : value;
            }
        });
        if (row.quadra && row.lote) data.push(row as ImportData);
    }
    return data;
  };

  const validateRow = (row: ImportData): string[] => {
    const errors: string[] = [];
    if (!row.quadra) errors.push('Quadra é obrigatória');
    if (!row.lote) errors.push('Lote é obrigatório');
    if (row.cliente_status && !['Proprietário', 'Inquilino', 'Proprietário Morador', 'Dependente'].includes(row.cliente_status)) errors.push(`Cliente Status inválido: ${row.cliente_status}`);
    if (row.email1 && !/\S+@\S+\.\S+/.test(row.email1)) errors.push('Email 1 inválido');
    if (row.email2 && !/\S+@\S+\.\S+/.test(row.email2)) errors.push('Email 2 inválido');
    return errors;
  };

  const handleImport = async () => {
    if (!file) return;
    setLoading(true);
    setImportResults(null);
    try {
      const text = await file.text();
      const data = parseCSV(text);
      if (data.length === 0) throw new Error('Nenhum dado válido encontrado no arquivo.');
      const errors: string[] = [];
      let successCount = 0;
      for (let i = 0; i < data.length; i++) {
        const row = data[i];
        const rowErrors = ignoreValidation ? [] : validateRow(row);
        if (rowErrors.length > 0) { errors.push(`Linha ${i + 2}: ${rowErrors.join(', ')}`); continue; }
        try {
          let empreendimentoId: string | null = null;
          if (row.empreendimento) {
            const { data: existingEmp } = await supabase.from('empreendimentos').select('id').ilike('nome', row.empreendimento).single();
            if (existingEmp) empreendimentoId = existingEmp.id;
            else { const { data: newEmp } = await supabase.from('empreendimentos').insert([{ nome: row.empreendimento }]).select('id').single(); empreendimentoId = newEmp?.id || null; }
          }
          const loteData = { empreendimento_id: empreendimentoId, quadra: row.quadra, numero: row.lote, area_privativa: row.area_privativa, status: 'casa' as const };
          const { data: existingLote } = await supabase.from('lotes').select('id').eq('quadra', row.quadra).eq('numero', row.lote).maybeSingle();
          let loteId: string;
          if (existingLote) { await supabase.from('lotes').update(loteData).eq('id', existingLote.id); loteId = existingLote.id; } 
          else { const { data: newLote } = await supabase.from('lotes').insert([loteData]).select('id').single(); loteId = newLote!.id; }
          if (row.cliente && loteId) {
            const moradorData = { nome: row.cliente, cliente_status: row.cliente_status || 'Proprietário', telefone: row.telefone1 || row.telefone2 || row.telefone3, email: row.email1 || row.email2 };
            const { data: newMorador } = await supabase.from('moradores').insert([moradorData]).select('id').single();
            if (newMorador) await supabase.from('morador_lote').insert([{ morador_id: newMorador.id, lote_id: loteId }]);
          }
          successCount++;
        } catch (e) { errors.push(`Linha ${i + 2}: ${e instanceof Error ? e.message : 'Erro'}`); }
      }
      setImportResults({ success: successCount, errors });
    } catch (e) { setImportResults({ success: 0, errors: [e instanceof Error ? e.message : 'Erro'] }); } 
    finally { setLoading(false); }
  };

  const downloadTemplate = () => {
    const template = `empreendimento,quadra,lote,area_privativa,cliente,cliente_status,telefone1,telefone2,telefone3,email1,email2\nResidencial Alpha,QUADRA A,LT01,"300,50",João Silva,Proprietário Morador,(11) 1234-5678,(11) 9876-5432,,joao@email.com,\n`;
    const blob = new Blob([template], { type: 'text/csv;charset=utf-8;' });
    const link = document.createElement('a');
    link.href = URL.createObjectURL(blob);
    link.download = 'template_importacao.csv';
    link.click();
  };

  const handleBackup = async () => {
    setIsBackingUp(true);
    try {
      const { data, error } = await supabase.from('lotes').select(`*, empreendimento:empreendimentos(nome), moradores:morador_lote(morador:moradores(*, veiculos:morador_veiculo(veiculo:veiculos(*))))`);
      if (error) throw error;
      const flatData: any[] = [];
      const headers = ['empreendimento', 'lote_quadra', 'lote_numero', 'lote_status', 'lote_area', 'morador_nome', 'morador_status', 'morador_cpf', 'morador_telefone', 'morador_celular', 'morador_email', 'veiculo_placa', 'veiculo_marca', 'veiculo_modelo', 'veiculo_cor'];
      data.forEach((lote: any) => {
        if (lote.moradores.length === 0) {
          flatData.push({ empreendimento: lote.empreendimento?.nome, lote_quadra: lote.quadra, lote_numero: lote.numero, lote_status: lote.status, lote_area: lote.area_privativa });
        } else {
          lote.moradores.forEach((relMorador: any) => {
            const morador = relMorador.morador;
            if (morador.veiculos.length === 0) {
              flatData.push({ empreendimento: lote.empreendimento?.nome, lote_quadra: lote.quadra, lote_numero: lote.numero, lote_status: lote.status, lote_area: lote.area_privativa, morador_nome: morador.nome, morador_status: morador.cliente_status, morador_cpf: morador.cpf, morador_telefone: morador.telefone, morador_celular: morador.celular, morador_email: morador.email });
            } else {
              morador.veiculos.forEach((relVeiculo: any) => {
                const veiculo = relVeiculo.veiculo;
                flatData.push({ empreendimento: lote.empreendimento?.nome, lote_quadra: lote.quadra, lote_numero: lote.numero, lote_status: lote.status, lote_area: lote.area_privativa, morador_nome: morador.nome, morador_status: morador.cliente_status, morador_cpf: morador.cpf, morador_telefone: morador.telefone, morador_celular: morador.celular, morador_email: morador.email, veiculo_placa: veiculo.placa, veiculo_marca: veiculo.marca, veiculo_modelo: veiculo.modelo, veiculo_cor: veiculo.cor });
              });
            }
          });
        }
      });
      const csvRows = [headers.join(','), ...flatData.map(row => headers.map(header => `"${row[header] || ''}"`).join(','))];
      const csv = csvRows.join('\n');
      const blob = new Blob([`\uFEFF${csv}`], { type: 'text/csv;charset=utf-8;' });
      const link = document.createElement('a');
      link.href = URL.createObjectURL(blob);
      link.download = `backup_condominio_${new Date().toISOString().split('T')[0]}.csv`;
      link.click();
    } catch (e) { alert(`Erro ao gerar backup: ${e instanceof Error ? e.message : 'Erro'}`); } 
    finally { setIsBackingUp(false); }
  };

  const handleClearData = async () => {
    const confirmation = prompt('Esta ação é IRREVERSÍVEL e removerá TODOS os dados (exceto usuários).\nPara confirmar, digite "LIMPAR DADOS":');
    if (confirmation !== 'LIMPAR DADOS') { alert('Limpeza cancelada.'); return; }
    setIsClearing(true);
    try {
      await supabase.from('morador_lote').delete().neq('morador_id', '00000000-0000-0000-0000-000000000000');
      await supabase.from('morador_veiculo').delete().neq('morador_id', '00000000-0000-0000-0000-000000000000');
      await supabase.from('visitantes').delete().neq('id', '00000000-0000-0000-0000-000000000000');
      await supabase.from('moradores').delete().neq('id', '00000000-0000-0000-0000-000000000000');
      await supabase.from('veiculos').delete().neq('id', '00000000-0000-0000-0000-000000000000');
      await supabase.from('lotes').delete().neq('id', '00000000-0000-0000-0000-000000000000');
      await supabase.from('empreendimentos').delete().neq('id', '00000000-0000-0000-0000-000000000000');
      alert('Dados limpos com sucesso.');
      window.location.reload();
    } catch (e) { alert(`Erro ao limpar dados: ${e instanceof Error ? e.message : 'Erro'}`); } 
    finally { setIsClearing(false); }
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center"><h1 className="text-2xl font-bold text-gray-900">Manutenção de Dados</h1></div>
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div className="bg-white p-6 rounded-lg shadow-sm border border-gray-200">
          <h2 className="text-lg font-semibold text-gray-900 mb-4">Importar Dados da Planilha</h2>
          <div className="space-y-4">
            <div><label className="block text-sm font-medium text-gray-700 mb-2">Arquivo CSV</label><div className="border-2 border-dashed border-gray-300 rounded-lg p-6 text-center"><input type="file" accept=".csv" onChange={handleFileSelect} className="hidden" id="csv-upload" /><label htmlFor="csv-upload" className="cursor-pointer"><FileSpreadsheet className="w-12 h-12 text-gray-400 mx-auto mb-4" /><p className="text-sm text-gray-600">Clique para selecionar ou arraste</p></label></div>{file && <p className="text-sm text-green-600 mt-2">Arquivo: {file.name}</p>}</div>
            <div className="flex items-center"><input type="checkbox" id="ignore-validation" checked={ignoreValidation} onChange={(e) => setIgnoreValidation(e.target.checked)} className="h-4 w-4 text-orange-600 rounded" /><label htmlFor="ignore-validation" className="ml-2 text-sm text-gray-900">Ignorar regras de validação</label></div>
            <div className="flex space-x-3"><button onClick={handleImport} disabled={!file || loading} className="flex items-center px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 disabled:opacity-50"><Upload className="w-4 h-4 mr-2" />{loading ? 'Importando...' : 'Importar'}</button><button onClick={downloadTemplate} className="flex items-center px-4 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700"><Download className="w-4 h-4 mr-2" />Template</button></div>
          </div>
        </div>

        <div className="bg-white p-6 rounded-lg shadow-sm border border-gray-200 space-y-4">
          <div>
            <h2 className="text-lg font-semibold text-gray-900 mb-2">Backup e Restauração</h2>
            <p className="text-sm text-gray-600 mb-4">Exporte todos os dados do sistema para um único arquivo CSV ou limpe a base de dados.</p>
            <div className="flex space-x-3">
              <button onClick={handleBackup} disabled={isBackingUp} className="flex items-center px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 disabled:opacity-50"><DatabaseBackup className="w-4 h-4 mr-2" />{isBackingUp ? 'Gerando...' : 'Backup Completo'}</button>
              <button onClick={handleClearData} disabled={isClearing} className="flex items-center px-4 py-2 bg-red-600 text-white rounded-lg hover:bg-red-700 disabled:opacity-50"><Trash2 className="w-4 h-4 mr-2" />{isClearing ? 'Limpando...' : 'Limpar Dados'}</button>
            </div>
          </div>
          <div className="mt-6 p-4 bg-red-50 border border-red-200 rounded-md"><h3 className="text-sm font-medium text-red-900 mb-2 flex items-center"><AlertTriangle className="w-4 h-4 mr-2" />Atenção</h3><p className="text-sm text-red-800">A função "Limpar Dados" removerá permanentemente todos os registros de lotes, moradores, veículos e visitantes. Esta ação não pode ser desfeita. Faça um backup antes de prosseguir.</p></div>
        </div>
      </div>

      {importResults && (
        <div className="bg-white p-6 rounded-lg shadow-sm border border-gray-200">
          <h3 className="text-lg font-semibold text-gray-900 mb-4">Resultados da Importação</h3>
          <div className="space-y-4">
            <div className="flex items-center text-green-600"><CheckCircle2 className="w-5 h-5 mr-2" /><span className="font-medium">{importResults.success} registros importados</span></div>
            {importResults.errors.length > 0 && (
              <div>
                <div className="flex items-center text-red-600 mb-2"><AlertTriangle className="w-5 h-5 mr-2" /><span className="font-medium">{importResults.errors.length} erro(s)</span></div>
                <div className="bg-red-50 border border-red-200 rounded-md p-3 max-h-48 overflow-y-auto">{importResults.errors.map((error, index) => <p key={index} className="text-sm text-red-700">{error}</p>)}</div>
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
}
