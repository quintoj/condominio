import React from 'react';
import { Building, Edit2, Trash2, Users } from 'lucide-react';
import { Lote } from '../../types';

interface LoteCardProps {
  lote: Lote;
  onEdit: (lote: Lote) => void;
  onDelete: (loteId: string) => void;
}

export function LoteCard({ lote, onEdit, onDelete }: LoteCardProps) {
  const getStatusColor = (status: string) => {
    switch (status) {
      case 'vazio': return 'bg-gray-100 text-gray-800';
      case 'obra': return 'bg-yellow-100 text-yellow-800';
      case 'casa': return 'bg-green-100 text-green-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'vazio': return '⚪';
      case 'obra': return '🚧';
      case 'casa': return '🏠';
      default: return '❓';
    }
  };

  return (
    <div className="bg-white rounded-lg p-6 shadow-sm border border-gray-200">
      <div className="flex items-center justify-between mb-4">
        <div className="flex items-center">
          <div className="p-2 bg-green-100 rounded-lg"><Building className="w-6 h-6 text-green-600" /></div>
          <div className="ml-3">
            <h3 className="text-lg font-semibold text-gray-900">Quadra {lote.quadra}, Lote {lote.numero}</h3>
            <span className={`inline-flex items-center px-2 py-0.5 rounded-full text-xs font-medium ${getStatusColor(lote.status)}`}>{getStatusIcon(lote.status)} {lote.status}</span>
          </div>
        </div>
        <div className="flex space-x-2">
          <button onClick={() => onEdit(lote)} className="text-blue-600 hover:text-blue-900"><Edit2 className="w-4 h-4" /></button>
          <button onClick={() => onDelete(lote.id)} className="text-red-600 hover:text-red-900"><Trash2 className="w-4 h-4" /></button>
        </div>
      </div>
      <div className="space-y-3">
        <div className="space-y-1">
          {lote.empreendimento?.nome && <div className="text-sm"><span className="text-gray-500">Empreendimento:</span><span className="ml-2 text-gray-900">{lote.empreendimento.nome}</span></div>}
          {lote.area_privativa && <div className="text-sm"><span className="text-gray-500">Área:</span><span className="ml-2 text-gray-900">{lote.area_privativa}m²</span></div>}
        </div>
        <div className="border-t pt-3">
          <div className="flex items-center mb-2"><Users className="w-4 h-4 text-gray-500 mr-1" /><span className="text-sm font-medium text-gray-700">Moradores:</span></div>
          {lote.moradores && lote.moradores.length > 0 ? (
            <div className="space-y-1">
              {lote.moradores.map((rel: any) => (
                <div key={rel.morador.id} className="text-sm text-gray-600">
                  <div>{rel.morador.nome}</div>
                  <div className="text-xs text-gray-500">({rel.morador.cliente_status})</div>
                </div>
              ))}
            </div>
          ) : (<div className="text-sm text-gray-500">Nenhum morador associado</div>)}
        </div>
      </div>
    </div>
  );
}
