import React, { useState, useEffect } from 'react';
import { X, Save, Plus } from 'lucide-react';
import { supabase } from '../../lib/supabase';
import { Lote, Empreendimento } from '../../types';

interface LoteFormProps {
  lote: Lote | null;
  empreendimentos: Empreendimento[];
  onClose: () => void;
  onSave: () => void;
}

export function LoteForm({ lote, empreendimentos, onClose, onSave }: LoteFormProps) {
  const [formData, setFormData] = useState({
    empreendimento_id: '',
    quadra: '',
    numero: '',
    area_privativa: '',
    status: 'vazio' as 'vazio' | 'obra' | 'casa',
  });
  const [newEmpreendimento, setNewEmpreendimento] = useState('');
  const [showNewEmpreendimento, setShowNewEmpreendimento] = useState(false);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    if (lote) {
      setFormData({
        empreendimento_id: lote.empreendimento_id || '',
        quadra: lote.quadra || '',
        numero: lote.numero || '',
        area_privativa: lote.area_privativa?.toString() || '',
        status: lote.status || 'vazio',
      });
    }
  }, [lote]);

  const handleCreateEmpreendimento = async () => {
    if (!newEmpreendimento.trim()) return;

    try {
      const { data, error } = await supabase
        .from('empreendimentos')
        .insert([{ nome: newEmpreendimento.trim() }])
        .select()
        .single();

      if (error) throw error;

      setFormData({ ...formData, empreendimento_id: data.id });
      setNewEmpreendimento('');
      setShowNewEmpreendimento(false);
      
      // Atualizar lista de empreendimentos
      window.location.reload();
    } catch (error) {
      console.error('Erro ao criar empreendimento:', error);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);

    try {
      const dataToSave = {
        ...formData,
        empreendimento_id: formData.empreendimento_id || null,
        area_privativa: formData.area_privativa ? parseFloat(formData.area_privativa) : null,
      };

      if (lote) {
        const { error } = await supabase
          .from('lotes')
          .update(dataToSave)
          .eq('id', lote.id);
        if (error) throw error;
      } else {
        const { error } = await supabase
          .from('lotes')
          .insert([dataToSave]);
        if (error) throw error;
      }

      onSave();
    } catch (error) {
      console.error('Erro ao salvar lote:', error);
    } finally {
      setLoading(false);
    }
  };

  const statusOptions = [
    { value: 'vazio', label: '⚪ Vazio' },
    { value: 'obra', label: '🚧 Em Obra' },
    { value: 'casa', label: '🏠 Casa' },
  ];

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
      <div className="bg-white rounded-lg max-w-2xl w-full max-h-[90vh] overflow-y-auto">
        <div className="flex justify-between items-center p-6 border-b border-gray-200">
          <h2 className="text-xl font-semibold text-gray-900">
            {lote ? 'Editar Lote' : 'Novo Lote'}
          </h2>
          <button
            onClick={onClose}
            className="text-gray-400 hover:text-gray-600"
          >
            <X className="w-6 h-6" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="p-6 space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Quadra *
              </label>
              <input
                type="text"
                value={formData.quadra}
                onChange={(e) => setFormData({ ...formData, quadra: e.target.value })}
                placeholder="Ex: A, B, 1, 2"
                className="w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                required
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Número do Lote *
              </label>
              <input
                type="text"
                value={formData.numero}
                onChange={(e) => setFormData({ ...formData, numero: e.target.value })}
                placeholder="Ex: 1, 2, 3"
                className="w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                required
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Área Privativa (m²)
              </label>
              <input
                type="number"
                value={formData.area_privativa}
                onChange={(e) => setFormData({ ...formData, area_privativa: e.target.value })}
                placeholder="Ex: 300"
                step="0.01"
                className="w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Status
              </label>
              <select
                value={formData.status}
                onChange={(e) => setFormData({ ...formData, status: e.target.value as any })}
                className="w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              >
                {statusOptions.map(option => (
                  <option key={option.value} value={option.value}>
                    {option.label}
                  </option>
                ))}
              </select>
            </div>

            <div className="md:col-span-2">
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Empreendimento (Opcional)
              </label>
              <div className="flex space-x-2">
                <select
                  value={formData.empreendimento_id}
                  onChange={(e) => setFormData({ ...formData, empreendimento_id: e.target.value })}
                  className="flex-1 px-3 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                >
                  <option value="">Nenhum empreendimento</option>
                  {empreendimentos.map(emp => (
                    <option key={emp.id} value={emp.id}>{emp.nome}</option>
                  ))}
                </select>
                <button
                  type="button"
                  onClick={() => setShowNewEmpreendimento(!showNewEmpreendimento)}
                  className="px-3 py-2 bg-gray-200 text-gray-700 rounded-md hover:bg-gray-300 transition-colors"
                >
                  <Plus className="w-4 h-4" />
                </button>
              </div>

              {showNewEmpreendimento && (
                <div className="mt-2 flex space-x-2">
                  <input
                    type="text"
                    value={newEmpreendimento}
                    onChange={(e) => setNewEmpreendimento(e.target.value)}
                    placeholder="Nome do novo empreendimento"
                    className="flex-1 px-3 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  />
                  <button
                    type="button"
                    onClick={handleCreateEmpreendimento}
                    className="px-3 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 transition-colors"
                  >
                    Criar
                  </button>
                </div>
              )}
            </div>
          </div>

          <div className="flex justify-end space-x-3 pt-4 border-t">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 text-gray-700 bg-gray-200 rounded-md hover:bg-gray-300 transition-colors"
            >
              Cancelar
            </button>
            <button
              type="submit"
              disabled={loading}
              className="flex items-center px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 disabled:opacity-50 transition-colors"
            >
              <Save className="w-4 h-4 mr-2" />
              {loading ? 'Salvando...' : 'Salvar'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}
