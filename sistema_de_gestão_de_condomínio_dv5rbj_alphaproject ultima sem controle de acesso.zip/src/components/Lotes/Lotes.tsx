import React, { useState, useEffect, useMemo } from 'react';
import { Plus, Building, Search, LayoutGrid, List } from 'lucide-react';
import { supabase } from '../../lib/supabase';
import { Lote, Empreendimento } from '../../types';
import { LoteForm } from './LoteForm';
import { Pagination } from '../Common/Pagination';
import { LoteCard } from './LoteCard';
import { LotesTable } from './LotesTable';

export function Lotes() {
  const [lotes, setLotes] = useState<Lote[]>([]);
  const [empreendimentos, setEmpreendimentos] = useState<Empreendimento[]>([]);
  const [loading, setLoading] = useState(true);
  const [showForm, setShowForm] = useState(false);
  const [editingLote, setEditingLote] = useState<Lote | null>(null);
  const [filter, setFilter] = useState<'all' | 'vazio' | 'obra' | 'casa'>('all');
  const [searchTerm, setSearchTerm] = useState('');
  const [currentPage, setCurrentPage] = useState(1);
  const [viewMode, setViewMode] = useState<'grid' | 'table'>('grid');

  useEffect(() => { loadData(); }, []);

  const loadData = async () => {
    try {
      setLoading(true);
      const { data: empreendimentosData } = await supabase.from('empreendimentos').select('*').order('nome');
      setEmpreendimentos(empreendimentosData || []);
      const { data: lotesData } = await supabase.from('lotes').select(`*, empreendimento:empreendimentos(*), moradores:morador_lote(morador:moradores(*))`).order('quadra').order('numero');
      setLotes(lotesData || []);
    } catch (error) { console.error('Erro ao carregar dados:', error); } 
    finally { setLoading(false); }
  };

  const handleEdit = (lote: Lote) => { setEditingLote(lote); setShowForm(true); };
  const handleDelete = async (loteId: string) => { if (!confirm('Tem certeza?')) return; try { await supabase.from('morador_lote').delete().eq('lote_id', loteId); await supabase.from('lotes').delete().eq('id', loteId); loadData(); } catch (e) { console.error('Erro ao excluir lote:', e); }};

  const filteredLotes = useMemo(() => {
    return lotes
      .filter(lote => filter === 'all' || lote.status === filter)
      .filter(lote => lote.quadra.toLowerCase().includes(searchTerm.toLowerCase()) || lote.numero.toLowerCase().includes(searchTerm.toLowerCase()));
  }, [lotes, filter, searchTerm]);

  const itemsPerPage = viewMode === 'table' ? 10 : 9;
  const totalPages = Math.ceil(filteredLotes.length / itemsPerPage);
  const paginatedLotes = filteredLotes.slice((currentPage - 1) * itemsPerPage, currentPage * itemsPerPage);

  if (loading) return <div className="flex justify-center h-64"><div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600"></div></div>;

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center"><h1 className="text-2xl font-bold text-gray-900">Gestão de Lotes</h1><button onClick={() => { setEditingLote(null); setShowForm(true); }} className="flex items-center px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700"><Plus className="w-4 h-4 mr-2" />Novo Lote</button></div>

      <div className="bg-white p-4 rounded-lg shadow-sm border border-gray-200 space-y-4">
        <div className="flex justify-between items-center">
          <div className="relative w-full max-w-xs"><Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" /><input type="text" placeholder="Buscar por quadra ou lote..." value={searchTerm} onChange={(e) => { setSearchTerm(e.target.value); setCurrentPage(1); }} className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-md" /></div>
          <div className="flex items-center space-x-2"><button onClick={() => setViewMode('grid')} className={`p-2 rounded-md ${viewMode === 'grid' ? 'bg-blue-100 text-blue-600' : 'text-gray-500 hover:bg-gray-100'}`}><LayoutGrid className="w-5 h-5" /></button><button onClick={() => setViewMode('table')} className={`p-2 rounded-md ${viewMode === 'table' ? 'bg-blue-100 text-blue-600' : 'text-gray-500 hover:bg-gray-100'}`}><List className="w-5 h-5" /></button></div>
        </div>
        <div className="flex items-center space-x-4"><span className="text-sm font-medium text-gray-700">Status:</span><div className="flex space-x-2"><button onClick={() => setFilter('all')} className={`px-3 py-1 text-sm rounded-full ${filter === 'all' ? 'bg-blue-100 text-blue-800' : 'bg-gray-100'}`}>Todos</button><button onClick={() => setFilter('vazio')} className={`px-3 py-1 text-sm rounded-full ${filter === 'vazio' ? 'bg-gray-100' : 'bg-gray-100'}`}>⚪ Vazio</button><button onClick={() => setFilter('obra')} className={`px-3 py-1 text-sm rounded-full ${filter === 'obra' ? 'bg-yellow-100 text-yellow-800' : 'bg-gray-100'}`}>🚧 Em Obra</button><button onClick={() => setFilter('casa')} className={`px-3 py-1 text-sm rounded-full ${filter === 'casa' ? 'bg-green-100 text-green-800' : 'bg-gray-100'}`}>🏠 Casa</button></div></div>
      </div>

      {viewMode === 'grid' ? (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {paginatedLotes.map((lote) => <LoteCard key={lote.id} lote={lote} onEdit={handleEdit} onDelete={handleDelete} />)}
        </div>
      ) : (
        <LotesTable lotes={paginatedLotes} onEdit={handleEdit} onDelete={handleDelete} />
      )}

      {filteredLotes.length === 0 && <div className="text-center py-8 text-gray-500"><Building className="w-12 h-12 mx-auto mb-4 opacity-50" /><p>Nenhum lote encontrado</p></div>}
      <Pagination currentPage={currentPage} totalPages={totalPages} onPageChange={setCurrentPage} />

      {showForm && <LoteForm lote={editingLote} empreendimentos={empreendimentos} onClose={() => { setShowForm(false); setEditingLote(null); }} onSave={() => { loadData(); setShowForm(false); setEditingLote(null); }} />}
    </div>
  );
}
