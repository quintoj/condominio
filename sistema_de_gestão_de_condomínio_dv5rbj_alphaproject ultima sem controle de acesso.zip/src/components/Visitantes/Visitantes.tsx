import React, { useState, useEffect, useMemo } from 'react';
import { Plus, Filter, UserCheck, Clock, CheckCircle2, UserPlus, FileText, Calendar } from 'lucide-react';
import { supabase } from '../../lib/supabase';
import { Visitante, Lote } from '../../types';
import { VisitanteForm } from './VisitanteForm';
import { Pagination } from '../Common/Pagination';
import { RegistrarEntradaModal } from './RegistrarEntradaModal';
import { SortableHeader } from '../Common/SortableHeader';

export function Visitantes() {
  const [visitantes, setVisitantes] = useState<Visitante[]>([]);
  const [lotes, setLotes] = useState<Lote[]>([]);
  const [loading, setLoading] = useState(true);
  const [showForm, setShowForm] = useState(false);
  const [editingVisitante, setEditingVisitante] = useState<Visitante | null>(null);
  const [initialDataForNewEntry, setInitialDataForNewEntry] = useState<Partial<Visitante> | null>(null);
  const [filter, setFilter] = useState<'all' | 'present' | 'authorized'>('all');
  const [currentPage, setCurrentPage] = useState(1);
  const [itemsPerPage] = useState(10);
  const [showRegistrarEntradaModal, setShowRegistrarEntradaModal] = useState(false);
  const [sortConfig, setSortConfig] = useState<{ key: keyof Visitante; direction: 'asc' | 'desc' }>({ key: 'data_entrada', direction: 'desc' });
  const [dateRange, setDateRange] = useState({ start: '', end: '' });

  useEffect(() => { loadData(); }, []);

  const loadData = async () => {
    try {
      setLoading(true);
      const { data: lotesData } = await supabase.from('lotes').select('*, empreendimento:empreendimentos(*)').order('quadra').order('numero');
      setLotes(lotesData || []);
      const { data: visitantesData } = await supabase.from('visitantes').select('*, lote:lotes(*, empreendimento:empreendimentos(*))');
      setVisitantes(visitantesData || []);
    } catch (error) { console.error('Erro ao carregar dados:', error); } 
    finally { setLoading(false); }
  };

  const sortedVisitantes = useMemo(() => {
    let sortableItems = [...visitantes];
    sortableItems.sort((a, b) => {
      const aValue = (a as any)[sortConfig.key];
      const bValue = (b as any)[sortConfig.key];
      if (aValue < bValue) return sortConfig.direction === 'asc' ? -1 : 1;
      if (aValue > bValue) return sortConfig.direction === 'asc' ? 1 : -1;
      return 0;
    });
    return sortableItems;
  }, [visitantes, sortConfig]);

  const filteredVisitantes = useMemo(() => {
    return sortedVisitantes.filter(v => {
      const statusFilter = (filter === 'all') || (filter === 'present' && !v.data_saida) || (filter === 'authorized' && v.autorizado);
      if (!statusFilter) return false;

      if (dateRange.start && dateRange.end) {
        const entryDate = new Date(v.data_entrada);
        const startDate = new Date(dateRange.start);
        const endDate = new Date(dateRange.end);
        endDate.setHours(23, 59, 59, 999); // Include the whole end day
        return entryDate >= startDate && entryDate <= endDate;
      }
      return true;
    });
  }, [sortedVisitantes, filter, dateRange]);

  const handleSort = (key: keyof Visitante) => {
    let direction: 'asc' | 'desc' = 'asc';
    if (sortConfig.key === key && sortConfig.direction === 'asc') direction = 'desc';
    setSortConfig({ key, direction });
  };

  const handleEdit = (visitante: Visitante) => { setEditingVisitante(visitante); setShowForm(true); };
  const handleRegistrarSaida = async (id: string) => { try { await supabase.from('visitantes').update({ data_saida: new Date().toISOString() }).eq('id', id); loadData(); } catch (e) { console.error(e); }};
  const handleDelete = async (id: string) => { if (confirm('Tem certeza?')) { try { await supabase.from('visitantes').delete().eq('id', id); loadData(); } catch (e) { console.error(e); }}};
  const handleOpenNewEntry = (data: Partial<Visitante>) => { setInitialDataForNewEntry(data); setShowRegistrarEntradaModal(false); setShowForm(true); };
  const handleExportCSV = () => {
    const headers = ['Nome', 'Documento', 'Tipo Documento', 'Telefone', 'Classificação', 'Autorizado', 'CRECI', 'Tipo Serviço', 'Lote', 'Quadra', 'Empreendimento', 'Veículo', 'Cor Veículo', 'Placa Veículo', 'Data Entrada', 'Data Saída'];
    const rows = filteredVisitantes.map(v => [ `"${v.nome}"`, `"${v.documento}"`, v.tipo_documento, `"${v.telefone || ''}"`, v.classificacao, v.autorizado ? 'Sim' : 'Não', `"${v.creci || ''}"`, `"${v.tipo_servico || ''}"`, `"${v.lote?.numero || ''}"`, `"${v.lote?.quadra || ''}"`, `"${v.lote?.empreendimento?.nome || ''}"`, `"${v.veiculo || ''}"`, `"${v.veiculo_cor || ''}"`, `"${v.veiculo_placa || ''}"`, `"${new Date(v.data_entrada).toLocaleString('pt-BR')}"`, `"${v.data_saida ? new Date(v.data_saida).toLocaleString('pt-BR') : ''}"` ].join(','));
    const csv = [headers.join(','), ...rows].join('\n');
    const blob = new Blob([`\uFEFF${csv}`], { type: 'text/csv;charset=utf-8;' });
    const link = document.createElement('a');
    link.href = URL.createObjectURL(blob);
    link.download = `visitantes_relatorio_${new Date().toISOString().split('T')[0]}.csv`;
    link.click();
  };

  const totalPages = Math.ceil(filteredVisitantes.length / itemsPerPage);
  const paginatedVisitantes = filteredVisitantes.slice((currentPage - 1) * itemsPerPage, currentPage * itemsPerPage);
  const formatDateTime = (dt: string) => new Date(dt).toLocaleString('pt-BR');

  if (loading) return <div className="flex justify-center h-64"><div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600"></div></div>;

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h1 className="text-2xl font-bold text-gray-900">Gestão de Visitantes</h1>
        <div className="flex space-x-3"><button onClick={handleExportCSV} className="flex items-center px-4 py-2 bg-teal-600 text-white rounded-lg hover:bg-teal-700 transition-colors"><FileText className="w-4 h-4 mr-2" />Exportar</button><button onClick={() => setShowRegistrarEntradaModal(true)} className="flex items-center px-4 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700 transition-colors"><UserPlus className="w-4 h-4 mr-2" />Registrar Entrada</button><button onClick={() => { setEditingVisitante(null); setInitialDataForNewEntry(null); setShowForm(true); }} className="flex items-center px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"><Plus className="w-4 h-4 mr-2" />Novo Visitante</button></div>
      </div>

      <div className="bg-white p-4 rounded-lg shadow-sm border border-gray-200 space-y-4">
        <div className="flex items-center space-x-4"><Filter className="w-4 h-4 text-gray-500" /><div className="flex space-x-2"><button onClick={() => setFilter('all')} className={`px-3 py-1 text-sm rounded-full ${filter === 'all' ? 'bg-blue-100 text-blue-800' : 'bg-gray-100'}`}>Todos</button><button onClick={() => setFilter('present')} className={`px-3 py-1 text-sm rounded-full ${filter === 'present' ? 'bg-green-100 text-green-800' : 'bg-gray-100'}`}>Presentes</button><button onClick={() => setFilter('authorized')} className={`px-3 py-1 text-sm rounded-full ${filter === 'authorized' ? 'bg-purple-100 text-purple-800' : 'bg-gray-100'}`}>Autorizados</button></div></div>
        <div className="flex items-center space-x-4"><Calendar className="w-4 h-4 text-gray-500" /><div className="flex items-center gap-2"><label className="text-sm">De:</label><input type="date" value={dateRange.start} onChange={e => setDateRange(p => ({...p, start: e.target.value}))} className="px-2 py-1 border rounded-md text-sm" /><label className="text-sm">Até:</label><input type="date" value={dateRange.end} onChange={e => setDateRange(p => ({...p, end: e.target.value}))} className="px-2 py-1 border rounded-md text-sm" /><button onClick={() => setDateRange({start: '', end: ''})} className="text-xs text-gray-500 hover:text-gray-800">Limpar</button></div></div>
      </div>

      <div className="bg-white rounded-lg shadow-sm border border-gray-200 overflow-hidden">
        <div className="overflow-x-auto">
          <table className="min-w-full divide-y divide-gray-200">
            <thead className="bg-gray-50">
              <tr>
                <SortableHeader label="Visitante" sortKey="nome" sortConfig={sortConfig} onSort={handleSort} />
                <SortableHeader label="Documento" sortKey="documento" sortConfig={sortConfig} onSort={handleSort} />
                <SortableHeader label="Classificação" sortKey="classificacao" sortConfig={sortConfig} onSort={handleSort} />
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Lote</th>
                <SortableHeader label="Entrada" sortKey="data_entrada" sortConfig={sortConfig} onSort={handleSort} />
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Status</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Ações</th>
              </tr>
            </thead>
            <tbody className="bg-white divide-y divide-gray-200">
              {paginatedVisitantes.map((v) => (
                <tr key={v.id} className="hover:bg-gray-50">
                  <td className="px-6 py-4 whitespace-nowrap"><div><div className="text-sm font-medium text-gray-900">{v.nome}{v.autorizado && <span className="ml-2 inline-flex items-center px-2 py-0.5 rounded text-xs font-medium bg-purple-100 text-purple-800"><UserCheck className="w-3 h-3 mr-1" />Autorizado</span>}</div>{v.telefone && <div className="text-sm text-gray-500">{v.telefone}</div>}</div></td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900"><div><div>{v.documento}</div><div className="text-xs text-gray-500">({v.tipo_documento})</div></div></td>
                  <td className="px-6 py-4 whitespace-nowrap"><span className="inline-flex items-center px-2 py-0.5 rounded-full text-xs font-medium bg-blue-100 text-blue-800">{v.classificacao}</span>{v.creci && <div className="text-xs text-gray-500 mt-1">CRECI: {v.creci}</div>}{v.tipo_servico && <div className="text-xs text-gray-500 mt-1">{v.tipo_servico}</div>}</td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">{v.lote ? <div><div>Q {v.lote.quadra}, L {v.lote.numero}</div>{v.lote.empreendimento?.nome && <div className="text-xs text-gray-500">{v.lote.empreendimento.nome}</div>}</div> : 'N/A'}</td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">{formatDateTime(v.data_entrada)}</td>
                  <td className="px-6 py-4 whitespace-nowrap">{v.data_saida ? <div className="flex items-center text-green-600"><CheckCircle2 className="w-4 h-4 mr-1" /><span className="text-sm">Saída: {formatDateTime(v.data_saida)}</span></div> : <div className="flex items-center text-orange-600"><Clock className="w-4 h-4 mr-1" /><span className="text-sm">Presente</span></div>}</td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500"><div className="flex space-x-2"><button onClick={() => handleEdit(v)} className="text-blue-600 hover:text-blue-900">Editar</button>{!v.data_saida && <button onClick={() => handleRegistrarSaida(v.id)} className="text-green-600 hover:text-green-900">Saída</button>}<button onClick={() => handleDelete(v.id)} className="text-red-600 hover:text-red-900">Excluir</button></div></td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {paginatedVisitantes.length === 0 && <div className="text-center py-8 text-gray-500"><UserCheck className="w-12 h-12 mx-auto mb-4 opacity-50" /><p>Nenhum visitante encontrado</p></div>}
      <Pagination currentPage={currentPage} totalPages={totalPages} onPageChange={setCurrentPage} />

      {showForm && <VisitanteForm visitante={editingVisitante} initialData={initialDataForNewEntry} lotes={lotes} onClose={() => { setShowForm(false); setEditingVisitante(null); setInitialDataForNewEntry(null); }} onSave={() => { loadData(); setShowForm(false); setEditingVisitante(null); setInitialDataForNewEntry(null); }} />}
      <RegistrarEntradaModal isOpen={showRegistrarEntradaModal} onClose={() => setShowRegistrarEntradaModal(false)} onVisitorSelect={handleOpenNewEntry} />
    </div>
  );
}
