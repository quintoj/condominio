import React, { useState, useMemo } from 'react';
import { Search, UserPlus } from 'lucide-react';
import { supabase } from '../../lib/supabase';
import { Visitante } from '../../types';
import { Modal } from '../Common/Modal';

interface RegistrarEntradaModalProps {
  isOpen: boolean;
  onClose: () => void;
  onVisitorSelect: (visitor: Partial<Visitante>) => void;
}

export function RegistrarEntradaModal({ isOpen, onClose, onVisitorSelect }: RegistrarEntradaModalProps) {
  const [searchTerm, setSearchTerm] = useState('');
  const [searchResults, setSearchResults] = useState<Visitante[]>([]);
  const [loading, setLoading] = useState(false);

  const handleSearch = async () => {
    if (searchTerm.trim().length < 3) {
      setSearchResults([]);
      return;
    }
    setLoading(true);
    try {
      const { data, error } = await supabase
        .from('visitantes')
        .select('*')
        .or(`nome.ilike.%${searchTerm}%,documento.ilike.%${searchTerm}%`)
        .order('created_at', { ascending: false });

      if (error) throw error;
      setSearchResults(data || []);
    } catch (error) {
      console.error('Erro ao buscar visitantes:', error);
    } finally {
      setLoading(false);
    }
  };

  const uniqueVisitors = useMemo(() => {
    const unique = new Map<string, Visitante>();
    searchResults.forEach(visitor => {
      if (!unique.has(visitor.documento)) {
        unique.set(visitor.documento, visitor);
      }
    });
    return Array.from(unique.values());
  }, [searchResults]);

  const handleSelect = (visitor: Visitante) => {
    onVisitorSelect({
      nome: visitor.nome,
      documento: visitor.documento,
      tipo_documento: visitor.tipo_documento,
      telefone: visitor.telefone,
      classificacao: visitor.classificacao,
      autorizado: visitor.autorizado,
      creci: visitor.creci,
      tipo_servico: visitor.tipo_servico,
    });
  };

  return (
    <Modal title="Registrar Nova Entrada" isOpen={isOpen} onClose={onClose} size="lg">
      <div className="p-6 space-y-4">
        <p className="text-sm text-gray-600">
          Busque por um visitante existente para registrar uma nova entrada rapidamente.
        </p>
        <div className="flex items-center gap-2">
          <div className="relative flex-grow">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
            <input
              type="text"
              placeholder="Buscar por nome ou documento..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              onKeyPress={(e) => e.key === 'Enter' && handleSearch()}
              className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-blue-500 focus:border-transparent"
            />
          </div>
          <button
            onClick={handleSearch}
            disabled={loading}
            className="px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 disabled:opacity-50"
          >
            {loading ? '...' : 'Buscar'}
          </button>
        </div>

        <div className="max-h-64 overflow-y-auto border border-gray-200 rounded-md">
          {loading ? (
            <div className="p-4 text-center text-gray-500">Buscando...</div>
          ) : uniqueVisitors.length > 0 ? (
            <ul className="divide-y divide-gray-200">
              {uniqueVisitors.map(visitor => (
                <li key={visitor.id} className="p-3 hover:bg-gray-50 flex justify-between items-center">
                  <div>
                    <p className="font-medium text-gray-800">{visitor.nome}</p>
                    <p className="text-sm text-gray-500">{visitor.documento} ({visitor.tipo_documento})</p>
                  </div>
                  <button
                    onClick={() => handleSelect(visitor)}
                    className="flex items-center text-sm px-3 py-1 bg-green-100 text-green-700 rounded-md hover:bg-green-200"
                  >
                    <UserPlus className="w-4 h-4 mr-1" />
                    Selecionar
                  </button>
                </li>
              ))}
            </ul>
          ) : (
            <div className="p-4 text-center text-gray-500">Nenhum visitante encontrado.</div>
          )}
        </div>
      </div>
    </Modal>
  );
}
