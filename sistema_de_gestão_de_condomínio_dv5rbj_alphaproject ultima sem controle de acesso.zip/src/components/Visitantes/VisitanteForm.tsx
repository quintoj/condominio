import React, { useState, useEffect } from 'react';
import { X, Save } from 'lucide-react';
import { supabase } from '../../lib/supabase';
import { Visitante, Lote } from '../../types';

interface VisitanteFormProps {
  visitante: Visitante | null;
  initialData?: Partial<Visitante> | null;
  lotes: Lote[];
  onClose: () => void;
  onSave: () => void;
}

export function VisitanteForm({ visitante, initialData, lotes, onClose, onSave }: VisitanteFormProps) {
  const [formData, setFormData] = useState({
    nome: '',
    documento: '',
    tipo_documento: 'CPF' as 'CPF' | 'RG',
    telefone: '',
    classificacao: 'Visitante' as string,
    autorizado: false,
    creci: '',
    tipo_servico: '',
    lote_id: '',
    veiculo: '',
    veiculo_cor: '',
    veiculo_placa: '',
    data_entrada: new Date().toISOString().slice(0, 16),
    data_saida: '',
  });
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    if (visitante) {
      setFormData({
        nome: visitante.nome || '',
        documento: visitante.documento || '',
        tipo_documento: visitante.tipo_documento || 'CPF',
        telefone: visitante.telefone || '',
        classificacao: visitante.classificacao || 'Visitante',
        autorizado: visitante.autorizado || false,
        creci: visitante.creci || '',
        tipo_servico: visitante.tipo_servico || '',
        lote_id: visitante.lote_id || '',
        veiculo: visitante.veiculo || '',
        veiculo_cor: visitante.veiculo_cor || '',
        veiculo_placa: visitante.veiculo_placa || '',
        data_entrada: visitante.data_entrada ? new Date(visitante.data_entrada).toISOString().slice(0, 16) : '',
        data_saida: visitante.data_saida ? new Date(visitante.data_saida).toISOString().slice(0, 16) : '',
      });
    } else if (initialData) {
      setFormData(prev => ({
        ...prev,
        ...initialData,
        data_entrada: new Date().toISOString().slice(0, 16),
        data_saida: '',
      }));
    }
  }, [visitante, initialData]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);

    try {
      const dataToSave = {
        ...formData,
        lote_id: formData.lote_id || null,
        data_entrada: new Date(formData.data_entrada).toISOString(),
        data_saida: formData.data_saida ? new Date(formData.data_saida).toISOString() : null,
        creci: formData.classificacao === 'Corretor de imóveis' ? formData.creci : null,
        tipo_servico: formData.classificacao === 'Prestador de serviço' ? formData.tipo_servico : null,
      };

      if (visitante) {
        const { error } = await supabase.from('visitantes').update(dataToSave).eq('id', visitante.id);
        if (error) throw error;
      } else {
        const { error } = await supabase.from('visitantes').insert([dataToSave]);
        if (error) throw error;
      }

      onSave();
    } catch (error) {
      console.error('Erro ao salvar visitante:', error);
    } finally {
      setLoading(false);
    }
  };

  const classificacoes = ['Visitante', 'Entregador', 'Prestador de serviço', 'Corretor de imóveis', 'Outros'];
  const tiposServico = ['Enfermeiro', 'Jardineiro', 'Pedreiro', 'Diarista', 'Eletricista', 'Encanador', 'Pintor', 'Outros'];

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
      <div className="bg-white rounded-lg max-w-2xl w-full max-h-[90vh] overflow-y-auto">
        <div className="flex justify-between items-center p-6 border-b border-gray-200">
          <h2 className="text-xl font-semibold text-gray-900">{visitante ? 'Editar Visitante' : 'Novo Visitante'}</h2>
          <button onClick={onClose} className="text-gray-400 hover:text-gray-600"><X className="w-6 h-6" /></button>
        </div>

        <form onSubmit={handleSubmit} className="p-6 space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div><label className="block text-sm font-medium text-gray-700 mb-2">Nome *</label><input type="text" value={formData.nome} onChange={(e) => setFormData({ ...formData, nome: e.target.value })} className="w-full px-3 py-2 border border-gray-300 rounded-md" required /></div>
            <div><label className="block text-sm font-medium text-gray-700 mb-2">Telefone</label><input type="text" value={formData.telefone} onChange={(e) => setFormData({ ...formData, telefone: e.target.value })} className="w-full px-3 py-2 border border-gray-300 rounded-md" /></div>
            <div><label className="block text-sm font-medium text-gray-700 mb-2">Tipo de Documento *</label><select value={formData.tipo_documento} onChange={(e) => setFormData({ ...formData, tipo_documento: e.target.value as 'CPF' | 'RG' })} className="w-full px-3 py-2 border border-gray-300 rounded-md" required><option value="CPF">CPF</option><option value="RG">RG</option></select></div>
            <div><label className="block text-sm font-medium text-gray-700 mb-2">Número do Documento *</label><input type="text" value={formData.documento} onChange={(e) => setFormData({ ...formData, documento: e.target.value })} className="w-full px-3 py-2 border border-gray-300 rounded-md" required /></div>
            <div><label className="block text-sm font-medium text-gray-700 mb-2">Classificação</label><select value={formData.classificacao} onChange={(e) => setFormData({ ...formData, classificacao: e.target.value })} className="w-full px-3 py-2 border border-gray-300 rounded-md">{classificacoes.map(c => <option key={c} value={c}>{c}</option>)}</select></div>
            <div><label className="block text-sm font-medium text-gray-700 mb-2">Lote de Destino</label><select value={formData.lote_id} onChange={(e) => setFormData({ ...formData, lote_id: e.target.value })} className="w-full px-3 py-2 border border-gray-300 rounded-md"><option value="">Selecione um lote</option>{lotes.map(lote => <option key={lote.id} value={lote.id}>Q {lote.quadra}, L {lote.numero}{lote.empreendimento?.nome && ` - ${lote.empreendimento.nome}`}</option>)}</select></div>
            {formData.classificacao === 'Corretor de imóveis' && <div><label className="block text-sm font-medium text-gray-700 mb-2">CRECI</label><input type="text" value={formData.creci} onChange={(e) => setFormData({ ...formData, creci: e.target.value })} className="w-full px-3 py-2 border border-gray-300 rounded-md" /></div>}
            {formData.classificacao === 'Prestador de serviço' && <div><label className="block text-sm font-medium text-gray-700 mb-2">Tipo de Serviço</label><select value={formData.tipo_servico} onChange={(e) => setFormData({ ...formData, tipo_servico: e.target.value })} className="w-full px-3 py-2 border border-gray-300 rounded-md"><option value="">Selecione o tipo</option>{tiposServico.map(t => <option key={t} value={t}>{t}</option>)}</select></div>}
            <div><label className="block text-sm font-medium text-gray-700 mb-2">Data/Hora de Entrada *</label><input type="datetime-local" value={formData.data_entrada} onChange={(e) => setFormData({ ...formData, data_entrada: e.target.value })} className="w-full px-3 py-2 border border-gray-300 rounded-md" required /></div>
            <div><label className="block text-sm font-medium text-gray-700 mb-2">Data/Hora de Saída</label><input type="datetime-local" value={formData.data_saida} onChange={(e) => setFormData({ ...formData, data_saida: e.target.value })} className="w-full px-3 py-2 border border-gray-300 rounded-md" /></div>
          </div>
          <div className="border-t pt-4"><h3 className="text-lg font-medium text-gray-900 mb-4">Informações do Veículo</h3><div className="grid grid-cols-1 md:grid-cols-3 gap-4"><div><label className="block text-sm font-medium text-gray-700 mb-2">Veículo</label><input type="text" value={formData.veiculo} onChange={(e) => setFormData({ ...formData, veiculo: e.target.value })} placeholder="Ex: Honda Civic" className="w-full px-3 py-2 border border-gray-300 rounded-md" /></div><div><label className="block text-sm font-medium text-gray-700 mb-2">Cor</label><input type="text" value={formData.veiculo_cor} onChange={(e) => setFormData({ ...formData, veiculo_cor: e.target.value })} placeholder="Ex: Preto" className="w-full px-3 py-2 border border-gray-300 rounded-md" /></div><div><label className="block text-sm font-medium text-gray-700 mb-2">Placa</label><input type="text" value={formData.veiculo_placa} onChange={(e) => setFormData({ ...formData, veiculo_placa: e.target.value.toUpperCase() })} placeholder="Ex: ABC1234" className="w-full px-3 py-2 border border-gray-300 rounded-md" /></div></div></div>
          <div className="flex items-center"><input type="checkbox" id="autorizado" checked={formData.autorizado} onChange={(e) => setFormData({ ...formData, autorizado: e.target.checked })} className="h-4 w-4 text-blue-600 border-gray-300 rounded" /><label htmlFor="autorizado" className="ml-2 block text-sm text-gray-900">Visitante Autorizado (Acesso permanente)</label></div>
          <div className="flex justify-end space-x-3 pt-4 border-t"><button type="button" onClick={onClose} className="px-4 py-2 text-gray-700 bg-gray-200 rounded-md hover:bg-gray-300">Cancelar</button><button type="submit" disabled={loading} className="flex items-center px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 disabled:opacity-50"><Save className="w-4 h-4 mr-2" />{loading ? 'Salvando...' : 'Salvar'}</button></div>
        </form>
      </div>
    </div>
  );
}
