import React, { useState, useEffect } from 'react';
import { Users, Building, Car, UserCheck, Home, HardHat, LandPlot } from 'lucide-react';
import { StatCard } from './StatCard';
import { supabase } from '../../lib/supabase';
import { DashboardStats } from '../../types';

interface Distribution {
  [key: string]: number;
}

export function Dashboard() {
  const [stats, setStats] = useState<DashboardStats>({
    moradores: 0,
    lotes: 0,
    veiculos: 0,
    visitantesPresentes: 0,
  });
  const [moradoresDistribution, setMoradoresDistribution] = useState<Distribution>({});
  const [lotesDistribution, setLotesDistribution] = useState<Distribution>({});
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadStats();
  }, []);

  const loadStats = async () => {
    try {
      setLoading(true);

      // Contar moradores (Proprietário Morador, Inquilino, Dependente)
      const { count: moradoresCount } = await supabase
        .from('moradores')
        .select('*', { count: 'exact', head: true })
        .in('cliente_status', ['Proprietário Morador', 'Inquilino', 'Dependente']);

      // Contar lotes
      const { count: lotesCount } = await supabase
        .from('lotes')
        .select('*', { count: 'exact', head: true });

      // Contar veículos
      const { count: veiculosCount } = await supabase
        .from('veiculos')
        .select('*', { count: 'exact', head: true });

      // Contar visitantes presentes
      const { count: visitantesCount } = await supabase
        .from('visitantes')
        .select('*', { count: 'exact', head: true })
        .is('data_saida', null);

      // Carregar distribuição de moradores
      const { data: moradoresData } = await supabase
        .from('moradores')
        .select('cliente_status');

      const newMoradoresDistribution: Distribution = {
        'Proprietários': 0,
        'Inquilinos': 0,
        'Dependentes': 0,
      };

      moradoresData?.forEach(morador => {
        const status = morador.cliente_status;
        if (status === 'Proprietário' || status === 'Proprietário Morador') {
          newMoradoresDistribution['Proprietários']++;
        } else if (newMoradoresDistribution.hasOwnProperty(status)) {
          newMoradoresDistribution[status]++;
        }
      });
      
      setMoradoresDistribution(newMoradoresDistribution);

      // Carregar distribuição de lotes
      const { data: lotesData } = await supabase.from('lotes').select('status');
      const newLotesDistribution: Distribution = { 'casa': 0, 'obra': 0, 'vazio': 0 };
      lotesData?.forEach(lote => {
        if (lote.status && newLotesDistribution.hasOwnProperty(lote.status)) {
          newLotesDistribution[lote.status]++;
        }
      });
      setLotesDistribution(newLotesDistribution);

      setStats({
        moradores: moradoresCount || 0,
        lotes: lotesCount || 0,
        veiculos: veiculosCount || 0,
        visitantesPresentes: visitantesCount || 0,
      });

    } catch (error) {
      console.error('Erro ao carregar estatísticas:', error);
    } finally {
      setLoading(false);
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600"></div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <h1 className="text-2xl font-bold text-gray-900">Dashboard</h1>
      
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <StatCard title="Moradores" value={stats.moradores} icon={Users} color="blue" />
        <StatCard title="Lotes" value={stats.lotes} icon={Building} color="green" />
        <StatCard title="Veículos" value={stats.veiculos} icon={Car} color="purple" />
        <StatCard title="Visitantes Presentes" value={stats.visitantesPresentes} icon={UserCheck} color="yellow" />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="bg-white rounded-lg p-6 shadow-sm border border-gray-200">
          <h2 className="text-lg font-semibold text-gray-900 mb-4">
            Distribuição de Moradores
          </h2>
          {Object.keys(moradoresDistribution).length > 0 ? (
            <ul className="space-y-3">
              {Object.entries(moradoresDistribution).map(([key, value]) => (
                <li key={key} className="flex justify-between items-center text-sm">
                  <span className="text-gray-600">{key}</span>
                  <span className="font-bold text-gray-900 bg-gray-100 px-2 py-1 rounded">{value}</span>
                </li>
              ))}
            </ul>
          ) : (
            <div className="flex items-center justify-center h-32 text-gray-500">
              <p>Nenhum dado de distribuição disponível</p>
            </div>
          )}
        </div>

        <div className="bg-white rounded-lg p-6 shadow-sm border border-gray-200">
          <h2 className="text-lg font-semibold text-gray-900 mb-4">
            Distribuição de Lotes
          </h2>
          {Object.keys(lotesDistribution).length > 0 ? (
            <ul className="space-y-3">
              <li className="flex justify-between items-center text-sm">
                <span className="flex items-center text-gray-600"><Home className="w-4 h-4 mr-2 text-green-500" /> Casas</span>
                <span className="font-bold text-gray-900 bg-green-100 text-green-800 px-2 py-1 rounded">{lotesDistribution.casa || 0}</span>
              </li>
              <li className="flex justify-between items-center text-sm">
                <span className="flex items-center text-gray-600"><HardHat className="w-4 h-4 mr-2 text-yellow-500" /> Obras</span>
                <span className="font-bold text-gray-900 bg-yellow-100 text-yellow-800 px-2 py-1 rounded">{lotesDistribution.obra || 0}</span>
              </li>
              <li className="flex justify-between items-center text-sm">
                <span className="flex items-center text-gray-600"><LandPlot className="w-4 h-4 mr-2 text-gray-500" /> Terrenos Vazios</span>
                <span className="font-bold text-gray-900 bg-gray-100 text-gray-800 px-2 py-1 rounded">{lotesDistribution.vazio || 0}</span>
              </li>
            </ul>
          ) : (
            <div className="flex items-center justify-center h-32 text-gray-500">
              <p>Nenhum dado de distribuição disponível</p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
