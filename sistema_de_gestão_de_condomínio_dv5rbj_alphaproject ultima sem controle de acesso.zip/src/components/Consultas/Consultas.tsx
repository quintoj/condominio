import React, { useState, useMemo } from 'react';
import { Search, List, Eye, LayoutGrid } from 'lucide-react';
import { supabase } from '../../lib/supabase';
import { Morador } from '../../types';
import { ResultadoConsulta } from './ResultadoConsulta';
import { Pagination } from '../Common/Pagination';
import { ConsultasTable } from './ConsultasTable';

export type EnrichedMorador = Morador & {
  lotes: { lote: { id: string; quadra: string; numero: string; empreendimento: { nome: string } } }[];
  veiculos: { veiculo: { id: string; marca: string; modelo: string; placa: string; cor: string } }[];
};

export function Consultas() {
  const [searchTerm, setSearchTerm] = useState('');
  const [results, setResults] = useState<EnrichedMorador[]>([]);
  const [loading, setLoading] = useState(false);
  const [currentPage, setCurrentPage] = useState(1);
  const [searched, setSearched] = useState(false);
  const [viewMode, setViewMode] = useState<'grid' | 'table'>('grid');
  const [sortConfig, setSortConfig] = useState<{ key: string; direction: 'asc' | 'desc' } | null>({ key: 'endereco', direction: 'asc' });

  const fetchData = async (term: string | null) => {
    setLoading(true);
    setSearched(true);
    setResults([]);

    try {
      const fullSelect = `
        id, nome, cliente_status, email, telefone, celular,
        lotes:morador_lote(
          lote:lotes(id, quadra, numero, empreendimento:empreendimentos(nome))
        ),
        veiculos:morador_veiculo(
          veiculo:veiculos(id, marca, modelo, placa, cor)
        )
      `;

      if (!term) {
        const { data, error } = await supabase.from('moradores').select(fullSelect);
        if (error) throw error;
        setResults(data as EnrichedMorador[]);
        setCurrentPage(1);
        setLoading(false);
        return;
      }

      const searchTermFormatted = `%${term}%`;
      const moradorIds = new Set<string>();

      const { data: byName } = await supabase.from('moradores').select('id').ilike('nome', searchTermFormatted);
      byName?.forEach(m => moradorIds.add(m.id));

      const { data: veiculos } = await supabase.from('veiculos').select('id').or(`placa.ilike.${searchTermFormatted},marca.ilike.${searchTermFormatted},modelo.ilike.${searchTermFormatted}`);
      if (veiculos && veiculos.length > 0) {
        const veiculoIds = veiculos.map(v => v.id);
        const { data: moradorVeiculo } = await supabase.from('morador_veiculo').select('morador_id').in('veiculo_id', veiculoIds);
        moradorVeiculo?.forEach(mv => moradorIds.add(mv.morador_id));
      }

      const { data: lotes } = await supabase.from('lotes').select('id').or(`quadra.ilike.${searchTermFormatted},numero.ilike.${searchTermFormatted}`);
      if (lotes && lotes.length > 0) {
        const loteIds = lotes.map(l => l.id);
        const { data: moradorLote } = await supabase.from('morador_lote').select('morador_id').in('lote_id', loteIds);
        moradorLote?.forEach(ml => moradorIds.add(ml.morador_id));
      }

      if (moradorIds.size > 0) {
        const { data: finalData, error } = await supabase
          .from('moradores')
          .select(fullSelect)
          .in('id', Array.from(moradorIds));
        if (error) throw error;
        setResults(finalData as EnrichedMorador[]);
      } else {
        setResults([]);
      }

      setCurrentPage(1);

    } catch (error) {
      console.error('Erro na busca:', error);
      setResults([]);
    } finally {
      setLoading(false);
    }
  };

  const sortedResults = useMemo(() => {
    let sortableItems = [...results];
    if (sortConfig !== null) {
      sortableItems.sort((a, b) => {
        let aValue: any, bValue: any;
        if (sortConfig.key === 'endereco') {
          aValue = a.lotes?.[0]?.lote ? `${a.lotes[0].lote.quadra}-${a.lotes[0].lote.numero}` : 'ZZZ';
          bValue = b.lotes?.[0]?.lote ? `${b.lotes[0].lote.quadra}-${b.lotes[0].lote.numero}` : 'ZZZ';
        } else {
          aValue = (a as any)[sortConfig.key];
          bValue = (b as any)[sortConfig.key];
        }

        if (aValue < bValue) return sortConfig.direction === 'asc' ? -1 : 1;
        if (aValue > bValue) return sortConfig.direction === 'asc' ? 1 : -1;
        return 0;
      });
    }
    return sortableItems;
  }, [results, sortConfig]);

  const handleSort = (key: string) => {
    let direction: 'asc' | 'desc' = 'asc';
    if (sortConfig && sortConfig.key === key && sortConfig.direction === 'asc') {
      direction = 'desc';
    }
    setSortConfig({ key, direction });
  };

  const handleSearch = () => {
    if (searchTerm.trim()) fetchData(searchTerm);
  };
  
  const handleListAll = () => {
    setSearchTerm('');
    fetchData(null);
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter') handleSearch();
  };

  const itemsToPaginate = viewMode === 'table' ? 10 : 9;
  const totalPages = Math.ceil(sortedResults.length / itemsToPaginate);
  const startIndex = (currentPage - 1) * itemsToPaginate;
  const endIndex = startIndex + itemsToPaginate;
  const currentResults = sortedResults.slice(startIndex, endIndex);

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h1 className="text-2xl font-bold text-gray-900">Consultas Unificadas</h1>
        <button onClick={handleListAll} className="flex items-center px-4 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700 transition-colors">
          <List className="w-4 h-4 mr-2" />
          Listar Todos
        </button>
      </div>

      <div className="bg-white p-6 rounded-lg shadow-sm border border-gray-200">
        <div className="flex items-end gap-4">
          <div className="flex-grow">
            <label className="block text-sm font-medium text-gray-700 mb-2">Buscar por nome, placa, quadra, lote, marca ou modelo</label>
            <div className="relative"><Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" /><input type="text" value={searchTerm} onChange={(e) => setSearchTerm(e.target.value)} onKeyPress={handleKeyPress} placeholder="Digite para buscar..." className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-blue-500 focus:border-transparent" /></div>
          </div>
          <button onClick={handleSearch} disabled={loading || !searchTerm.trim()} className="flex items-center h-10 px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 disabled:opacity-50 disabled:cursor-not-allowed transition-colors">
            <Search className="w-4 h-4 mr-2" />
            {loading ? 'Buscando...' : 'Buscar'}
          </button>
        </div>
      </div>

      {loading && <div className="flex items-center justify-center py-8"><div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600"></div></div>}

      {!loading && results.length > 0 && (
        <div className="space-y-4">
          <div className="flex justify-between items-center">
            <p className="text-sm text-gray-600">{results.length} resultado(s) encontrado(s)</p>
            <div className="flex items-center space-x-2">
              <button onClick={() => setViewMode('grid')} className={`p-2 rounded-md ${viewMode === 'grid' ? 'bg-blue-100 text-blue-600' : 'text-gray-500 hover:bg-gray-100'}`}><LayoutGrid className="w-5 h-5" /></button>
              <button onClick={() => setViewMode('table')} className={`p-2 rounded-md ${viewMode === 'table' ? 'bg-blue-100 text-blue-600' : 'text-gray-500 hover:bg-gray-100'}`}><List className="w-5 h-5" /></button>
            </div>
          </div>
          
          {viewMode === 'grid' ? (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {currentResults.map(morador => <ResultadoConsulta key={morador.id} morador={morador} />)}
            </div>
          ) : (
            <ConsultasTable resultados={currentResults} sortConfig={sortConfig} onSort={handleSort} />
          )}

          <Pagination currentPage={currentPage} totalPages={totalPages} onPageChange={setCurrentPage} />
        </div>
      )}

      {!loading && searched && results.length === 0 && (
        <div className="text-center py-8 text-gray-500"><Eye className="w-12 h-12 mx-auto mb-4 opacity-50" /><p>Nenhum resultado encontrado</p></div>
      )}
    </div>
  );
}
