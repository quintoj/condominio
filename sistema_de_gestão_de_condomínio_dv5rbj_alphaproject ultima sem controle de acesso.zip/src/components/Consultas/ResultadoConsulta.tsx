import React from 'react';
import { User, Building, Car, Home } from 'lucide-react';
import { Morador, Lote, Veiculo } from '../../types';

interface ResultadoConsultaProps {
  morador: Morador & { lotes?: (Lote & { empreendimento?: { nome: string } })[], veiculos?: Veiculo[] };
}

export function ResultadoConsulta({ morador }: ResultadoConsultaProps) {
  return (
    <div className="bg-white p-4 rounded-lg border border-gray-200 shadow-sm w-full">
      {/* Morador */}
      <div className="flex items-start justify-between mb-3">
        <div className="flex items-center">
          <User className="w-5 h-5 text-blue-600 mr-2" />
          <div>
            <h3 className="font-semibold text-gray-900">{morador.nome}</h3>
            <span className="text-xs bg-blue-100 text-blue-800 px-2 py-0.5 rounded-full">
              {morador.cliente_status}
            </span>
          </div>
        </div>
      </div>

      <div className="space-y-3 pl-7">
        {/* Lotes */}
        {morador.lotes && morador.lotes.length > 0 && (
          <div>
            <h4 className="text-sm font-medium text-gray-600 mb-1 flex items-center">
              <Building className="w-4 h-4 mr-2" /> Endereços
            </h4>
            <div className="space-y-1">
              {morador.lotes.map((lote: any) => (
                <div key={lote.lote.id} className="text-sm text-gray-800 bg-gray-50 p-2 rounded">
                  <p>Quadra {lote.lote.quadra}, Lote {lote.lote.numero}</p>
                  {lote.lote.empreendimento?.nome && (
                    <p className="text-xs text-gray-500 flex items-center">
                      <Home className="w-3 h-3 mr-1" /> {lote.lote.empreendimento.nome}
                    </p>
                  )}
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Veículos */}
        {morador.veiculos && morador.veiculos.length > 0 && (
          <div>
            <h4 className="text-sm font-medium text-gray-600 mb-1 flex items-center">
              <Car className="w-4 h-4 mr-2" /> Veículos
            </h4>
            <div className="space-y-1">
              {morador.veiculos.map((veiculo: any) => (
                <div key={veiculo.veiculo.id} className="text-sm text-gray-800 bg-gray-50 p-2 rounded">
                  <p>{veiculo.veiculo.marca} {veiculo.veiculo.modelo} - <span className="font-mono">{veiculo.veiculo.placa}</span></p>
                  {veiculo.veiculo.cor && <p className="text-xs text-gray-500">Cor: {veiculo.veiculo.cor}</p>}
                </div>
              ))}
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
