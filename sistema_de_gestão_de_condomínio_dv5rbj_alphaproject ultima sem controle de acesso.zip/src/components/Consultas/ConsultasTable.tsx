import React from 'react';
import { EnrichedMorador } from './Consultas';
import { SortableHeader } from '../Common/SortableHeader';

interface ConsultasTableProps {
  resultados: EnrichedMorador[];
  sortConfig: { key: string; direction: 'asc' | 'desc' } | null;
  onSort: (key: string) => void;
}

export function ConsultasTable({ resultados, sortConfig, onSort }: ConsultasTableProps) {
  return (
    <div className="bg-white rounded-lg shadow-sm border border-gray-200 overflow-hidden">
      <div className="overflow-x-auto">
        <table className="min-w-full divide-y divide-gray-200">
          <thead className="bg-gray-50">
            <tr>
              <SortableHeader label="Endereço" sortKey="endereco" sortConfig={sortConfig} onSort={onSort} />
              <SortableHeader label="Morador" sortKey="nome" sortConfig={sortConfig} onSort={onSort} />
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Veículos</th>
            </tr>
          </thead>
          <tbody className="bg-white divide-y divide-gray-200">
            {resultados.map((morador) => (
              <tr key={morador.id} className="hover:bg-gray-50">
                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                  {morador.lotes?.map((rel: any) => (
                    <div key={rel.lote.id}>
                      Q: {rel.lote.quadra}, L: {rel.lote.numero}
                      <span className="text-xs text-gray-500 ml-1">({rel.lote.empreendimento?.nome})</span>
                    </div>
                  ))}
                </td>
                <td className="px-6 py-4 whitespace-nowrap">
                  <div className="text-sm font-medium text-gray-900">{morador.nome}</div>
                  <div className="text-sm text-gray-500">{morador.cliente_status}</div>
                </td>
                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                  {morador.veiculos?.map((rel: any) => (
                    <div key={rel.veiculo.id}>
                      {rel.veiculo.marca} {rel.veiculo.modelo}
                      <span className="font-mono text-xs bg-gray-100 px-1 rounded ml-1">{rel.veiculo.placa}</span>
                    </div>
                  ))}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
