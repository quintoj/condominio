import React from 'react';
import { 
  Home, 
  Search, 
  Users, 
  Car, 
  UserCheck, 
  Building, 
  Database,
  LogOut
} from 'lucide-react';
import { useAuth } from '../../contexts/AuthContext';

interface SidebarProps {
  activeSection: string;
  onSectionChange: (section: string) => void;
}

export function Sidebar({ activeSection, onSectionChange }: SidebarProps) {
  const { signOut } = useAuth();

  const menuItems = [
    { id: 'dashboard', label: 'Dashboard', icon: Home },
    { id: 'consultas', label: 'Consultas', icon: Search },
    { id: 'visitantes', label: 'Visitantes', icon: UserCheck },
    { id: 'veiculos', label: 'Veículos', icon: Car },
    { id: 'moradores', label: 'Moradores', icon: Users },
    { id: 'lotes', label: 'Lotes', icon: Building },
    { id: 'manutencao', label: 'Manutenção', icon: Database },
  ];

  const handleSignOut = async () => {
    await signOut();
  };

  return (
    <div className="w-64 bg-blue-600 text-white h-screen flex flex-col">
      <div className="p-6 border-b border-blue-500">
        <h1 className="text-xl font-bold">Condomínio</h1>
      </div>
      
      <nav className="flex-1 py-4">
        {menuItems.map((item) => {
          const Icon = item.icon;
          return (
            <button
              key={item.id}
              onClick={() => onSectionChange(item.id)}
              className={`w-full flex items-center px-6 py-3 text-left hover:bg-blue-700 transition-colors ${
                activeSection === item.id ? 'bg-blue-700 border-r-4 border-white' : ''
              }`}
            >
              <Icon className="w-5 h-5 mr-3" />
              {item.label}
            </button>
          );
        })}
      </nav>

      <div className="p-4 border-t border-blue-500">
        <button
          onClick={handleSignOut}
          className="w-full flex items-center px-2 py-2 text-left hover:bg-blue-700 transition-colors rounded"
        >
          <LogOut className="w-5 h-5 mr-3" />
          Sair
        </button>
      </div>
    </div>
  );
}
