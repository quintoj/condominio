import React, { useState, useEffect, useMemo } from 'react';
import { Plus, Users, Search, List, LayoutGrid } from 'lucide-react';
import { supabase } from '../../lib/supabase';
import { Morador, Lote } from '../../types';
import { MoradorForm } from './MoradorForm';
import { Pagination } from '../Common/Pagination';
import { MoradoresTable } from './MoradoresTable';

export function Moradores() {
  const [moradores, setMoradores] = useState<Morador[]>([]);
  const [lotes, setLotes] = useState<Lote[]>([]);
  const [loading, setLoading] = useState(true);
  const [showForm, setShowForm] = useState(false);
  const [editingMorador, setEditingMorador] = useState<Morador | null>(null);
  const [searchTerm, setSearchTerm] = useState('');
  const [viewMode, setViewMode] = useState<'grid' | 'table'>('grid');
  const [currentPage, setCurrentPage] = useState(1);
  const [sortConfig, setSortConfig] = useState<{ key: string; direction: 'asc' | 'desc' } | null>({ key: 'endereco', direction: 'asc' });

  useEffect(() => { loadData(); }, []);

  const loadData = async () => {
    try {
      setLoading(true);
      const { data: moradoresData } = await supabase.from('moradores').select(`*, lotes:morador_lote(lote:lotes(*, empreendimento:empreendimentos(*))), veiculos:morador_veiculo(veiculo:veiculos(*))`);
      setMoradores(moradoresData || []);
      const { data: lotesData } = await supabase.from('lotes').select('*, empreendimento:empreendimentos(*)').order('quadra').order('numero');
      setLotes(lotesData || []);
    } catch (error) { console.error('Erro ao carregar dados:', error); } 
    finally { setLoading(false); }
  };

  const handleEdit = (morador: Morador) => { setEditingMorador(morador); setShowForm(true); };
  const handleDelete = async (moradorId: string) => { if (!confirm('Tem certeza?')) return; try { await supabase.from('morador_lote').delete().eq('morador_id', moradorId); await supabase.from('morador_veiculo').delete().eq('morador_id', moradorId); await supabase.from('moradores').delete().eq('id', moradorId); loadData(); } catch (e) { console.error('Erro ao excluir morador:', e); }};

  const sortedMoradores = useMemo(() => {
    let sortableItems = [...moradores];
    if (sortConfig) {
      sortableItems.sort((a, b) => {
        let aValue: any, bValue: any;
        if (sortConfig.key === 'endereco') {
          aValue = a.lotes?.[0]?.lote ? `${a.lotes[0].lote.quadra}-${a.lotes[0].lote.numero}` : 'ZZZ';
          bValue = b.lotes?.[0]?.lote ? `${b.lotes[0].lote.quadra}-${b.lotes[0].lote.numero}` : 'ZZZ';
        } else {
          aValue = (a as any)[sortConfig.key];
          bValue = (b as any)[sortConfig.key];
        }
        if (aValue < bValue) return sortConfig.direction === 'asc' ? -1 : 1;
        if (aValue > bValue) return sortConfig.direction === 'asc' ? 1 : -1;
        return 0;
      });
    }
    return sortableItems;
  }, [moradores, sortConfig]);

  const filteredMoradores = useMemo(() => {
    return sortedMoradores.filter(m => m.nome.toLowerCase().includes(searchTerm.toLowerCase()));
  }, [sortedMoradores, searchTerm]);

  const handleSort = (key: string) => {
    let direction: 'asc' | 'desc' = 'asc';
    if (sortConfig && sortConfig.key === key && sortConfig.direction === 'asc') direction = 'desc';
    setSortConfig({ key, direction });
  };
  
  const itemsPerPage = viewMode === 'table' ? 10 : 9;
  const totalPages = Math.ceil(filteredMoradores.length / itemsPerPage);
  const paginatedMoradores = filteredMoradores.slice((currentPage - 1) * itemsPerPage, currentPage * itemsPerPage);

  if (loading) return <div className="flex justify-center h-64"><div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600"></div></div>;

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center"><h1 className="text-2xl font-bold text-gray-900">Gestão de Moradores</h1><button onClick={() => { setEditingMorador(null); setShowForm(true); }} className="flex items-center px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700"><Plus className="w-4 h-4 mr-2" />Novo Morador</button></div>
      <div className="bg-white p-4 rounded-lg shadow-sm border border-gray-200 flex justify-between items-center">
        <div className="relative w-full max-w-xs"><Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" /><input type="text" placeholder="Buscar por nome..." value={searchTerm} onChange={(e) => { setSearchTerm(e.target.value); setCurrentPage(1); }} className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-md" /></div>
        <div className="flex items-center space-x-2"><button onClick={() => setViewMode('grid')} className={`p-2 rounded-md ${viewMode === 'grid' ? 'bg-blue-100 text-blue-600' : 'text-gray-500 hover:bg-gray-100'}`}><LayoutGrid className="w-5 h-5" /></button><button onClick={() => setViewMode('table')} className={`p-2 rounded-md ${viewMode === 'table' ? 'bg-blue-100 text-blue-600' : 'text-gray-500 hover:bg-gray-100'}`}><List className="w-5 h-5" /></button></div>
      </div>

      {viewMode === 'grid' ? (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {paginatedMoradores.map((morador) => <MoradorCard key={morador.id} morador={morador} onEdit={handleEdit} onDelete={handleDelete} />)}
        </div>
      ) : (
        <MoradoresTable moradores={paginatedMoradores} onEdit={handleEdit} onDelete={handleDelete} sortConfig={sortConfig} onSort={handleSort} />
      )}

      {filteredMoradores.length === 0 && <div className="text-center py-8 text-gray-500"><Users className="w-12 h-12 mx-auto mb-4 opacity-50" /><p>Nenhum morador encontrado</p></div>}
      <Pagination currentPage={currentPage} totalPages={totalPages} onPageChange={setCurrentPage} />

      {showForm && <MoradorForm morador={editingMorador} lotes={lotes} onClose={() => { setShowForm(false); setEditingMorador(null); }} onSave={() => { loadData(); setShowForm(false); setEditingMorador(null); }} />}
    </div>
  );
}

// Card component for grid view
import { Edit2, Trash2, Home } from 'lucide-react';
function MoradorCard({ morador, onEdit, onDelete }: { morador: Morador, onEdit: (m: Morador) => void, onDelete: (id: string) => void }) {
  const getStatusColor = (s: string) => ({'Proprietário': 'bg-blue-100 text-blue-800','Inquilino': 'bg-yellow-100 text-yellow-800','Proprietário Morador': 'bg-green-100 text-green-800','Dependente': 'bg-purple-100 text-purple-800'}[s] || 'bg-gray-100');
  return (
    <div className="bg-white rounded-lg p-6 shadow-sm border border-gray-200 flex flex-col">
      <div className="flex items-center justify-between mb-4">
        <div className="flex items-center"><div className="p-2 bg-blue-100 rounded-lg"><Users className="w-6 h-6 text-blue-600" /></div><div className="ml-3"><h3 className="text-lg font-semibold text-gray-900">{morador.nome}</h3><span className={`inline-flex items-center px-2 py-0.5 rounded-full text-xs font-medium ${getStatusColor(morador.cliente_status)}`}>{morador.cliente_status}</span></div></div>
        <div className="flex space-x-2"><button onClick={() => onEdit(morador)} className="text-blue-600 hover:text-blue-900"><Edit2 className="w-4 h-4" /></button><button onClick={() => onDelete(morador.id)} className="text-red-600 hover:text-red-900"><Trash2 className="w-4 h-4" /></button></div>
      </div>
      <div className="space-y-3 flex-grow">
        <div className="space-y-1">{morador.cpf && <div className="text-sm"><span className="text-gray-500">CPF:</span><span className="ml-2 text-gray-900">{morador.cpf}</span></div>}{morador.telefone && <div className="text-sm"><span className="text-gray-500">Telefone:</span><span className="ml-2 text-gray-900">{morador.telefone}</span></div>}{morador.email && <div className="text-sm"><span className="text-gray-500">Email:</span><span className="ml-2 text-gray-900">{morador.email}</span></div>}</div>
        <div className="border-t pt-3"><div className="flex items-center mb-2"><Home className="w-4 h-4 text-gray-500 mr-1" /><span className="text-sm font-medium text-gray-700">Endereços:</span></div>{morador.lotes && morador.lotes.length > 0 ? (<div className="space-y-1">{morador.lotes.map((rel: any) => (<div key={rel.lote.id} className="text-sm text-gray-600">Quadra {rel.lote.quadra}, Lote {rel.lote.numero}{rel.lote.empreendimento?.nome && <div className="text-xs text-gray-500">{rel.lote.empreendimento.nome}</div>}</div>))}</div>) : (<div className="text-sm text-gray-500">Nenhum endereço</div>)}</div>
      </div>
    </div>
  );
}
