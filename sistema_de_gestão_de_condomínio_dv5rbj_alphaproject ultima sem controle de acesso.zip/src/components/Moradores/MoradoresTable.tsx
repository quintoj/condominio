import React from 'react';
import { Edit2, Trash2 } from 'lucide-react';
import { Morador } from '../../types';
import { SortableHeader } from '../Common/SortableHeader';

interface MoradoresTableProps {
  moradores: Morador[];
  onEdit: (morador: Morador) => void;
  onDelete: (moradorId: string) => void;
  sortConfig: { key: string; direction: 'asc' | 'desc' } | null;
  onSort: (key: string) => void;
}

export function MoradoresTable({ moradores, onEdit, onDelete, sortConfig, onSort }: MoradoresTableProps) {
  const getStatusColor = (status: string) => {
    switch (status) {
      case 'Proprietário': return 'bg-blue-100 text-blue-800';
      case 'Inquilino': return 'bg-yellow-100 text-yellow-800';
      case 'Proprietário Morador': return 'bg-green-100 text-green-800';
      case 'Dependente': return 'bg-purple-100 text-purple-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  return (
    <div className="bg-white rounded-lg shadow-sm border border-gray-200 overflow-hidden">
      <div className="overflow-x-auto">
        <table className="min-w-full divide-y divide-gray-200">
          <thead className="bg-gray-50">
            <tr>
              <SortableHeader label="Nome" sortKey="nome" sortConfig={sortConfig} onSort={onSort} />
              <SortableHeader label="Status" sortKey="cliente_status" sortConfig={sortConfig} onSort={onSort} />
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Contato</th>
              <SortableHeader label="Endereço" sortKey="endereco" sortConfig={sortConfig} onSort={onSort} />
              <th className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">Ações</th>
            </tr>
          </thead>
          <tbody className="bg-white divide-y divide-gray-200">
            {moradores.map((morador) => (
              <tr key={morador.id} className="hover:bg-gray-50">
                <td className="px-6 py-4 whitespace-nowrap">
                  <div className="text-sm font-medium text-gray-900">{morador.nome}</div>
                  <div className="text-sm text-gray-500">{morador.cpf || 'CPF não informado'}</div>
                </td>
                <td className="px-6 py-4 whitespace-nowrap">
                  <span className={`px-2 inline-flex text-xs leading-5 font-semibold rounded-full ${getStatusColor(morador.cliente_status)}`}>
                    {morador.cliente_status}
                  </span>
                </td>
                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                  <div>{morador.celular || morador.telefone}</div>
                  <div className="text-xs text-gray-500">{morador.email}</div>
                </td>
                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                  {morador.lotes?.map((rel: any) => (
                    <div key={rel.lote.id}>Q: {rel.lote.quadra}, L: {rel.lote.numero}</div>
                  ))}
                </td>
                <td className="px-6 py-4 whitespace-nowrap text-right text-sm font-medium">
                  <div className="flex justify-end space-x-4">
                    <button onClick={() => onEdit(morador)} className="text-blue-600 hover:text-blue-900"><Edit2 className="w-4 h-4" /></button>
                    <button onClick={() => onDelete(morador.id)} className="text-red-600 hover:text-red-900"><Trash2 className="w-4 h-4" /></button>
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
