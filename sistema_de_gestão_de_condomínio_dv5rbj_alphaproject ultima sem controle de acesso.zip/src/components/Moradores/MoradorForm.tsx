import React, { useState, useEffect } from 'react';
import { X, Save } from 'lucide-react';
import { supabase } from '../../lib/supabase';
import { Morador, Lote } from '../../types';

interface MoradorFormProps {
  morador: Morador | null;
  lotes: Lote[];
  onClose: () => void;
  onSave: () => void;
}

export function MoradorForm({ morador, lotes, onClose, onSave }: MoradorFormProps) {
  const [formData, setFormData] = useState({
    nome: '',
    cpf: '',
    identidade: '',
    telefone: '',
    celular: '',
    email: '',
    cliente_status: 'Proprietário' as string,
  });
  const [selectedLotes, setSelectedLotes] = useState<string[]>([]);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    if (morador) {
      setFormData({
        nome: morador.nome || '',
        cpf: morador.cpf || '',
        identidade: morador.identidade || '',
        telefone: morador.telefone || '',
        celular: morador.celular || '',
        email: morador.email || '',
        cliente_status: morador.cliente_status || 'Proprietário',
      });

      // Carregar lotes associados
      if (morador.lotes) {
        const loteIds = morador.lotes.map((rel: any) => rel.lote.id);
        setSelectedLotes(loteIds);
      }
    }
  }, [morador]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);

    try {
      let moradorId: string;

      if (morador) {
        // Atualizar morador existente
        const { error } = await supabase
          .from('moradores')
          .update(formData)
          .eq('id', morador.id);
        if (error) throw error;
        moradorId = morador.id;
      } else {
        // Criar novo morador
        const { data, error } = await supabase
          .from('moradores')
          .insert([formData])
          .select()
          .single();
        if (error) throw error;
        moradorId = data.id;
      }

      // Atualizar associações com lotes
      // Primeiro, remover associações existentes
      await supabase
        .from('morador_lote')
        .delete()
        .eq('morador_id', moradorId);

      // Depois, adicionar novas associações
      if (selectedLotes.length > 0) {
        const associations = selectedLotes.map(loteId => ({
          morador_id: moradorId,
          lote_id: loteId,
        }));

        const { error } = await supabase
          .from('morador_lote')
          .insert(associations);
        if (error) throw error;
      }

      onSave();
    } catch (error) {
      console.error('Erro ao salvar morador:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleLoteToggle = (loteId: string) => {
    setSelectedLotes(prev => 
      prev.includes(loteId)
        ? prev.filter(id => id !== loteId)
        : [...prev, loteId]
    );
  };

  const clienteStatusOptions = [
    'Proprietário',
    'Inquilino',
    'Proprietário Morador',
    'Dependente'
  ];

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
      <div className="bg-white rounded-lg max-w-2xl w-full max-h-[90vh] overflow-y-auto">
        <div className="flex justify-between items-center p-6 border-b border-gray-200">
          <h2 className="text-xl font-semibold text-gray-900">
            {morador ? 'Editar Morador' : 'Novo Morador'}
          </h2>
          <button
            onClick={onClose}
            className="text-gray-400 hover:text-gray-600"
          >
            <X className="w-6 h-6" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="p-6 space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="md:col-span-2">
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Nome Completo *
              </label>
              <input
                type="text"
                value={formData.nome}
                onChange={(e) => setFormData({ ...formData, nome: e.target.value })}
                className="w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                required
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                CPF
              </label>
              <input
                type="text"
                value={formData.cpf}
                onChange={(e) => setFormData({ ...formData, cpf: e.target.value })}
                placeholder="000.000.000-00"
                className="w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Identidade
              </label>
              <input
                type="text"
                value={formData.identidade}
                onChange={(e) => setFormData({ ...formData, identidade: e.target.value })}
                className="w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Telefone
              </label>
              <input
                type="text"
                value={formData.telefone}
                onChange={(e) => setFormData({ ...formData, telefone: e.target.value })}
                placeholder="(11) 1234-5678"
                className="w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Celular
              </label>
              <input
                type="text"
                value={formData.celular}
                onChange={(e) => setFormData({ ...formData, celular: e.target.value })}
                placeholder="(11) 98765-4321"
                className="w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              />
            </div>

            <div className="md:col-span-2">
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Email
              </label>
              <input
                type="email"
                value={formData.email}
                onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                placeholder="exemplo@email.com"
                className="w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              />
            </div>

            <div className="md:col-span-2">
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Status do Cliente
              </label>
              <select
                value={formData.cliente_status}
                onChange={(e) => setFormData({ ...formData, cliente_status: e.target.value })}
                className="w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              >
                {clienteStatusOptions.map(status => (
                  <option key={status} value={status}>{status}</option>
                ))}
              </select>
            </div>
          </div>

          {/* Seleção de lotes */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Endereços (Lotes)
            </label>
            <div className="border border-gray-300 rounded-md p-3 max-h-48 overflow-y-auto">
              {lotes.length > 0 ? (
                <div className="space-y-2">
                  {lotes.map((lote) => (
                    <label key={lote.id} className="flex items-center cursor-pointer">
                      <input
                        type="checkbox"
                        checked={selectedLotes.includes(lote.id)}
                        onChange={() => handleLoteToggle(lote.id)}
                        className="h-4 w-4 text-blue-600 focus:ring-blue-500 border-gray-300 rounded"
                      />
                      <span className="ml-2 text-sm text-gray-900">
                        Quadra {lote.quadra}, Lote {lote.numero}
                        {lote.empreendimento?.nome && (
                          <span className="text-gray-500 ml-1">- {lote.empreendimento.nome}</span>
                        )}
                        <span className="ml-2 text-xs bg-gray-100 px-2 py-0.5 rounded capitalize">
                          {lote.status}
                        </span>
                      </span>
                    </label>
                  ))}
                </div>
              ) : (
                <p className="text-sm text-gray-500">Nenhum lote cadastrado</p>
              )}
            </div>
            <p className="text-xs text-gray-500 mt-1">
              Você pode associar o morador a múltiplos lotes
            </p>
          </div>

          <div className="flex justify-end space-x-3 pt-4 border-t">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 text-gray-700 bg-gray-200 rounded-md hover:bg-gray-300 transition-colors"
            >
              Cancelar
            </button>
            <button
              type="submit"
              disabled={loading}
              className="flex items-center px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 disabled:opacity-50 transition-colors"
            >
              <Save className="w-4 h-4 mr-2" />
              {loading ? 'Salvando...' : 'Salvar'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}
