import React, { useState, useEffect } from 'react';
import { X, Save } from 'lucide-react';
import { supabase } from '../../lib/supabase';
import { Veiculo, Morador } from '../../types';

interface VeiculoFormProps {
  veiculo: Veiculo | null;
  moradores: Morador[];
  onClose: () => void;
  onSave: () => void;
}

export function VeiculoForm({ veiculo, moradores, onClose, onSave }: VeiculoFormProps) {
  const [formData, setFormData] = useState({
    marca: '',
    modelo: '',
    cor: '',
    placa: '',
  });
  const [selectedMoradores, setSelectedMoradores] = useState<string[]>([]);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    if (veiculo) {
      setFormData({
        marca: veiculo.marca || '',
        modelo: veiculo.modelo || '',
        cor: veiculo.cor || '',
        placa: veiculo.placa || '',
      });

      // Carregar moradores associados
      if (veiculo.moradores) {
        const moradoreIds = veiculo.moradores.map((rel: any) => rel.morador.id);
        setSelectedMoradores(moradoreIds);
      }
    }
  }, [veiculo]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);

    try {
      let veiculoId: string;

      if (veiculo) {
        // Atualizar veículo existente
        const { error } = await supabase
          .from('veiculos')
          .update(formData)
          .eq('id', veiculo.id);
        if (error) throw error;
        veiculoId = veiculo.id;
      } else {
        // Criar novo veículo
        const { data, error } = await supabase
          .from('veiculos')
          .insert([formData])
          .select()
          .single();
        if (error) throw error;
        veiculoId = data.id;
      }

      // Atualizar associações com moradores
      // Primeiro, remover associações existentes
      await supabase
        .from('morador_veiculo')
        .delete()
        .eq('veiculo_id', veiculoId);

      // Depois, adicionar novas associações
      if (selectedMoradores.length > 0) {
        const associations = selectedMoradores.map(moradorId => ({
          morador_id: moradorId,
          veiculo_id: veiculoId,
        }));

        const { error } = await supabase
          .from('morador_veiculo')
          .insert(associations);
        if (error) throw error;
      }

      onSave();
    } catch (error) {
      console.error('Erro ao salvar veículo:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleMoradorToggle = (moradorId: string) => {
    setSelectedMoradores(prev => 
      prev.includes(moradorId)
        ? prev.filter(id => id !== moradorId)
        : [...prev, moradorId]
    );
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
      <div className="bg-white rounded-lg max-w-2xl w-full max-h-[90vh] overflow-y-auto">
        <div className="flex justify-between items-center p-6 border-b border-gray-200">
          <h2 className="text-xl font-semibold text-gray-900">
            {veiculo ? 'Editar Veículo' : 'Novo Veículo'}
          </h2>
          <button
            onClick={onClose}
            className="text-gray-400 hover:text-gray-600"
          >
            <X className="w-6 h-6" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="p-6 space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Marca
              </label>
              <input
                type="text"
                value={formData.marca}
                onChange={(e) => setFormData({ ...formData, marca: e.target.value })}
                placeholder="Ex: Honda"
                className="w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Modelo
              </label>
              <input
                type="text"
                value={formData.modelo}
                onChange={(e) => setFormData({ ...formData, modelo: e.target.value })}
                placeholder="Ex: Civic"
                className="w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Cor
              </label>
              <input
                type="text"
                value={formData.cor}
                onChange={(e) => setFormData({ ...formData, cor: e.target.value })}
                placeholder="Ex: Preto"
                className="w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Placa *
              </label>
              <input
                type="text"
                value={formData.placa}
                onChange={(e) => setFormData({ ...formData, placa: e.target.value.toUpperCase() })}
                placeholder="Ex: ABC1234"
                className="w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                required
              />
            </div>
          </div>

          {/* Seleção de moradores */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Proprietários do Veículo
            </label>
            <div className="border border-gray-300 rounded-md p-3 max-h-48 overflow-y-auto">
              {moradores.length > 0 ? (
                <div className="space-y-2">
                  {moradores.map((morador) => (
                    <label key={morador.id} className="flex items-center cursor-pointer">
                      <input
                        type="checkbox"
                        checked={selectedMoradores.includes(morador.id)}
                        onChange={() => handleMoradorToggle(morador.id)}
                        className="h-4 w-4 text-blue-600 focus:ring-blue-500 border-gray-300 rounded"
                      />
                      <span className="ml-2 text-sm text-gray-900">
                        {morador.nome}
                        <span className="text-gray-500 ml-1">({morador.cliente_status})</span>
                      </span>
                    </label>
                  ))}
                </div>
              ) : (
                <p className="text-sm text-gray-500">Nenhum morador cadastrado</p>
              )}
            </div>
            <p className="text-xs text-gray-500 mt-1">
              Você pode associar o veículo a múltiplos moradores
            </p>
          </div>

          <div className="flex justify-end space-x-3 pt-4 border-t">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 text-gray-700 bg-gray-200 rounded-md hover:bg-gray-300 transition-colors"
            >
              Cancelar
            </button>
            <button
              type="submit"
              disabled={loading}
              className="flex items-center px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 disabled:opacity-50 transition-colors"
            >
              <Save className="w-4 h-4 mr-2" />
              {loading ? 'Salvando...' : 'Salvar'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}
