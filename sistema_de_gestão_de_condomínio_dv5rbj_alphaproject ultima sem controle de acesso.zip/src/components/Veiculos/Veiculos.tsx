import React, { useState, useEffect, useMemo } from 'react';
import { Plus, Car, Edit2, Trash2, Search } from 'lucide-react';
import { supabase } from '../../lib/supabase';
import { Veiculo, Morador } from '../../types';
import { VeiculoForm } from './VeiculoForm';
import { Pagination } from '../Common/Pagination';

export function Veiculos() {
  const [veiculos, setVeiculos] = useState<Veiculo[]>([]);
  const [moradores, setMoradores] = useState<Morador[]>([]);
  const [loading, setLoading] = useState(true);
  const [showForm, setShowForm] = useState(false);
  const [editingVeiculo, setEditingVeiculo] = useState<Veiculo | null>(null);
  const [searchTerm, setSearchTerm] = useState('');
  const [currentPage, setCurrentPage] = useState(1);
  const [itemsPerPage] = useState(10);

  useEffect(() => { loadData(); }, []);

  const loadData = async () => {
    try {
      setLoading(true);
      const { data: veiculosData } = await supabase.from('veiculos').select(`*, moradores:morador_veiculo(morador:moradores(*))`).order('marca');
      setVeiculos(veiculosData || []);
      const { data: moradoresData } = await supabase.from('moradores').select('*').order('nome');
      setMoradores(moradoresData || []);
    } catch (error) { console.error('Erro ao carregar dados:', error); } 
    finally { setLoading(false); }
  };

  const handleEdit = (veiculo: Veiculo) => { setEditingVeiculo(veiculo); setShowForm(true); };
  const handleDelete = async (veiculoId: string) => { if (!confirm('Tem certeza?')) return; try { await supabase.from('morador_veiculo').delete().eq('veiculo_id', veiculoId); await supabase.from('veiculos').delete().eq('id', veiculoId); loadData(); } catch (e) { console.error('Erro ao excluir veículo:', e); }};

  const filteredVeiculos = useMemo(() => {
    if (!searchTerm) return veiculos;
    const term = searchTerm.toLowerCase();
    return veiculos.filter(v => 
      v.marca?.toLowerCase().includes(term) ||
      v.modelo?.toLowerCase().includes(term) ||
      v.placa.toLowerCase().includes(term) ||
      v.moradores?.some((m: any) => m.morador.nome.toLowerCase().includes(term))
    );
  }, [veiculos, searchTerm]);

  const totalPages = Math.ceil(filteredVeiculos.length / itemsPerPage);
  const paginatedVeiculos = filteredVeiculos.slice((currentPage - 1) * itemsPerPage, currentPage * itemsPerPage);

  if (loading) return <div className="flex justify-center h-64"><div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600"></div></div>;

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center"><h1 className="text-2xl font-bold text-gray-900">Gestão de Veículos</h1><button onClick={() => { setEditingVeiculo(null); setShowForm(true); }} className="flex items-center px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700"><Plus className="w-4 h-4 mr-2" />Novo Veículo</button></div>
      
      <div className="bg-white p-4 rounded-lg shadow-sm border border-gray-200">
        <div className="relative w-full max-w-md"><Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" /><input type="text" placeholder="Buscar por marca, modelo, placa ou proprietário..." value={searchTerm} onChange={e => setSearchTerm(e.target.value)} className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-md" /></div>
      </div>

      <div className="bg-white rounded-lg shadow-sm border border-gray-200 overflow-hidden">
        <div className="overflow-x-auto">
          <table className="min-w-full divide-y divide-gray-200">
            <thead className="bg-gray-50">
              <tr>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Veículo</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Placa</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Proprietários</th>
                <th className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">Ações</th>
              </tr>
            </thead>
            <tbody className="bg-white divide-y divide-gray-200">
              {paginatedVeiculos.map((veiculo) => (
                <tr key={veiculo.id} className="hover:bg-gray-50">
                  <td className="px-6 py-4 whitespace-nowrap">
                    <div className="text-sm font-medium text-gray-900">{veiculo.marca} {veiculo.modelo}</div>
                    <div className="text-sm text-gray-500">{veiculo.cor}</div>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap"><div className="text-sm font-mono bg-gray-100 px-2 py-1 rounded inline-block">{veiculo.placa}</div></td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">{veiculo.moradores?.map((m: any) => m.morador.nome).join(', ') || 'N/A'}</td>
                  <td className="px-6 py-4 whitespace-nowrap text-right text-sm font-medium">
                    <div className="flex justify-end space-x-4">
                      <button onClick={() => handleEdit(veiculo)} className="text-blue-600 hover:text-blue-900"><Edit2 className="w-4 h-4" /></button>
                      <button onClick={() => handleDelete(veiculo.id)} className="text-red-600 hover:text-red-900"><Trash2 className="w-4 h-4" /></button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {filteredVeiculos.length === 0 && <div className="text-center py-8 text-gray-500"><Car className="w-12 h-12 mx-auto mb-4 opacity-50" /><p>Nenhum veículo encontrado</p></div>}
      <Pagination currentPage={currentPage} totalPages={totalPages} onPageChange={setCurrentPage} />

      {showForm && <VeiculoForm veiculo={editingVeiculo} moradores={moradores} onClose={() => { setShowForm(false); setEditingVeiculo(null); }} onSave={() => { loadData(); setShowForm(false); setEditingVeiculo(null); }} />}
    </div>
  );
}
