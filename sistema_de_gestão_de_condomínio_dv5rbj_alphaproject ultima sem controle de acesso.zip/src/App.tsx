import React, { useState } from 'react';
import { AuthProvider, useAuth } from './contexts/AuthContext';
import { Login } from './components/Auth/Login';
import { Sidebar } from './components/Layout/Sidebar';
import { Dashboard } from './components/Dashboard/Dashboard';
import { Consultas } from './components/Consultas/Consultas';
import { Visitantes } from './components/Visitantes/Visitantes';
import { Veiculos } from './components/Veiculos/Veiculos';
import { Moradores } from './components/Moradores/Moradores';
import { Lotes } from './components/Lotes/Lotes';
import { Manutencao } from './components/Manutencao/Manutencao';

function AppContent() {
  const { user, loading } = useAuth();
  const [activeSection, setActiveSection] = useState('dashboard');

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-100 flex items-center justify-center">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600"></div>
      </div>
    );
  }

  if (!user) {
    return <Login />;
  }

  const renderContent = () => {
    switch (activeSection) {
      case 'dashboard':
        return <Dashboard />;
      case 'consultas':
        return <Consultas />;
      case 'visitantes':
        return <Visitantes />;
      case 'veiculos':
        return <Veiculos />;
      case 'moradores':
        return <Moradores />;
      case 'lotes':
        return <Lotes />;
      case 'manutencao':
        return <Manutencao />;
      default:
        return <Dashboard />;
    }
  };

  return (
    <div className="flex h-screen bg-gray-100">
      <Sidebar activeSection={activeSection} onSectionChange={setActiveSection} />
      <main className="flex-1 overflow-auto">
        <div className="p-6">
          {renderContent()}
        </div>
      </main>
    </div>
  );
}

function App() {
  return (
    <AuthProvider>
      <AppContent />
    </AuthProvider>
  );
}

export default App;
