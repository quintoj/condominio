/*
# Criação do Schema do Sistema de Condomínio

Criação das tabelas principais para o sistema de gestão de condomínio horizontal,
incluindo estruturas para empreendimentos, lotes, moradores, veículos e visitantes.

## Query Description:
Esta operação criará toda a estrutura do banco de dados para o sistema de condomínio.
Inclui tabelas para gestão de moradores, lotes, veículos e visitantes, com relacionamentos
apropriados e políticas de segurança (RLS). Operação segura que não afeta dados existentes.

## Metadata:
- Schema-Category: "Structural"
- Impact-Level: "Low"
- Requires-Backup: false
- Reversible: true

## Structure Details:
- empreendimentos: dados dos condomínios
- lotes: quadras e lotes do condomínio
- moradores: dados dos residentes
- veiculos: veículos dos moradores
- morador_lote: relacionamento moradores-lotes
- morador_veiculo: relacionamento moradores-veículos
- visitantes: controle de acesso de visitantes

## Security Implications:
- RLS Status: Enabled
- Policy Changes: Yes
- Auth Requirements: Authenticated users only

## Performance Impact:
- Indexes: Added for performance
- Triggers: Added for UUID generation
- Estimated Impact: Minimal performance impact
*/

-- Enable UUID extension
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- Empreendimentos table
CREATE TABLE IF NOT EXISTS public.empreendimentos (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    nome VARCHAR(255) NOT NULL,
    endereco TEXT,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT TIMEZONE('utc'::text, NOW()) NOT NULL,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT TIMEZONE('utc'::text, NOW()) NOT NULL
);

-- Lotes table
CREATE TABLE IF NOT EXISTS public.lotes (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    empreendimento_id UUID REFERENCES public.empreendimentos(id) ON DELETE SET NULL,
    quadra VARCHAR(50) NOT NULL,
    numero VARCHAR(50) NOT NULL,
    area_privativa DECIMAL(10,2),
    status VARCHAR(20) DEFAULT 'vazio' CHECK (status IN ('vazio', 'obra', 'casa')),
    created_at TIMESTAMP WITH TIME ZONE DEFAULT TIMEZONE('utc'::text, NOW()) NOT NULL,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT TIMEZONE('utc'::text, NOW()) NOT NULL,
    UNIQUE(empreendimento_id, quadra, numero)
);

-- Moradores table
CREATE TABLE IF NOT EXISTS public.moradores (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    nome VARCHAR(255) NOT NULL,
    cpf VARCHAR(14),
    identidade VARCHAR(20),
    telefone VARCHAR(20),
    celular VARCHAR(20),
    email VARCHAR(255),
    cliente_status VARCHAR(50) NOT NULL CHECK (cliente_status IN ('Proprietário', 'Inquilino', 'Proprietário Morador', 'Dependente')),
    created_at TIMESTAMP WITH TIME ZONE DEFAULT TIMEZONE('utc'::text, NOW()) NOT NULL,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT TIMEZONE('utc'::text, NOW()) NOT NULL
);

-- Veículos table
CREATE TABLE IF NOT EXISTS public.veiculos (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    marca VARCHAR(100),
    modelo VARCHAR(100),
    cor VARCHAR(50),
    placa VARCHAR(10) NOT NULL UNIQUE,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT TIMEZONE('utc'::text, NOW()) NOT NULL,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT TIMEZONE('utc'::text, NOW()) NOT NULL
);

-- Relacionamento morador-lote (many-to-many)
CREATE TABLE IF NOT EXISTS public.morador_lote (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    morador_id UUID NOT NULL REFERENCES public.moradores(id) ON DELETE CASCADE,
    lote_id UUID NOT NULL REFERENCES public.lotes(id) ON DELETE CASCADE,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT TIMEZONE('utc'::text, NOW()) NOT NULL,
    UNIQUE(morador_id, lote_id)
);

-- Relacionamento morador-veículo (many-to-many)
CREATE TABLE IF NOT EXISTS public.morador_veiculo (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    morador_id UUID NOT NULL REFERENCES public.moradores(id) ON DELETE CASCADE,
    veiculo_id UUID NOT NULL REFERENCES public.veiculos(id) ON DELETE CASCADE,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT TIMEZONE('utc'::text, NOW()) NOT NULL,
    UNIQUE(morador_id, veiculo_id)
);

-- Visitantes table
CREATE TABLE IF NOT EXISTS public.visitantes (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    nome VARCHAR(255) NOT NULL,
    documento VARCHAR(20) NOT NULL,
    tipo_documento VARCHAR(3) NOT NULL CHECK (tipo_documento IN ('CPF', 'RG')),
    telefone VARCHAR(20),
    classificacao VARCHAR(50) NOT NULL CHECK (classificacao IN ('Visitante', 'Entregador', 'Prestador de serviço', 'Corretor de imóveis', 'Outros')),
    autorizado BOOLEAN DEFAULT FALSE,
    creci VARCHAR(20),
    tipo_servico VARCHAR(100),
    lote_id UUID REFERENCES public.lotes(id) ON DELETE SET NULL,
    veiculo VARCHAR(100),
    veiculo_cor VARCHAR(50),
    veiculo_placa VARCHAR(10),
    data_entrada TIMESTAMP WITH TIME ZONE DEFAULT TIMEZONE('utc'::text, NOW()) NOT NULL,
    data_saida TIMESTAMP WITH TIME ZONE,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT TIMEZONE('utc'::text, NOW()) NOT NULL,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT TIMEZONE('utc'::text, NOW()) NOT NULL
);

-- Indexes for performance
CREATE INDEX IF NOT EXISTS idx_lotes_quadra_numero ON public.lotes(quadra, numero);
CREATE INDEX IF NOT EXISTS idx_moradores_cpf ON public.moradores(cpf);
CREATE INDEX IF NOT EXISTS idx_moradores_cliente_status ON public.moradores(cliente_status);
CREATE INDEX IF NOT EXISTS idx_veiculos_placa ON public.veiculos(placa);
CREATE INDEX IF NOT EXISTS idx_visitantes_data_entrada ON public.visitantes(data_entrada);
CREATE INDEX IF NOT EXISTS idx_visitantes_data_saida ON public.visitantes(data_saida);
CREATE INDEX IF NOT EXISTS idx_visitantes_classificacao ON public.visitantes(classificacao);

-- Function to update updated_at timestamp
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = TIMEZONE('utc'::text, NOW());
    RETURN NEW;
END;
$$ language 'plpgsql';

-- Triggers for updated_at
CREATE TRIGGER update_empreendimentos_updated_at BEFORE UPDATE ON public.empreendimentos FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
CREATE TRIGGER update_lotes_updated_at BEFORE UPDATE ON public.lotes FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
CREATE TRIGGER update_moradores_updated_at BEFORE UPDATE ON public.moradores FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
CREATE TRIGGER update_veiculos_updated_at BEFORE UPDATE ON public.veiculos FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
CREATE TRIGGER update_visitantes_updated_at BEFORE UPDATE ON public.visitantes FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

-- Enable RLS
ALTER TABLE public.empreendimentos ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.lotes ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.moradores ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.veiculos ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.morador_lote ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.morador_veiculo ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.visitantes ENABLE ROW LEVEL SECURITY;

-- RLS Policies
CREATE POLICY "Authenticated users can view empreendimentos" ON public.empreendimentos FOR SELECT TO authenticated USING (true);
CREATE POLICY "Authenticated users can insert empreendimentos" ON public.empreendimentos FOR INSERT TO authenticated WITH CHECK (true);
CREATE POLICY "Authenticated users can update empreendimentos" ON public.empreendimentos FOR UPDATE TO authenticated USING (true);
CREATE POLICY "Authenticated users can delete empreendimentos" ON public.empreendimentos FOR DELETE TO authenticated USING (true);

CREATE POLICY "Authenticated users can view lotes" ON public.lotes FOR SELECT TO authenticated USING (true);
CREATE POLICY "Authenticated users can insert lotes" ON public.lotes FOR INSERT TO authenticated WITH CHECK (true);
CREATE POLICY "Authenticated users can update lotes" ON public.lotes FOR UPDATE TO authenticated USING (true);
CREATE POLICY "Authenticated users can delete lotes" ON public.lotes FOR DELETE TO authenticated USING (true);

CREATE POLICY "Authenticated users can view moradores" ON public.moradores FOR SELECT TO authenticated USING (true);
CREATE POLICY "Authenticated users can insert moradores" ON public.moradores FOR INSERT TO authenticated WITH CHECK (true);
CREATE POLICY "Authenticated users can update moradores" ON public.moradores FOR UPDATE TO authenticated USING (true);
CREATE POLICY "Authenticated users can delete moradores" ON public.moradores FOR DELETE TO authenticated USING (true);

CREATE POLICY "Authenticated users can view veiculos" ON public.veiculos FOR SELECT TO authenticated USING (true);
CREATE POLICY "Authenticated users can insert veiculos" ON public.veiculos FOR INSERT TO authenticated WITH CHECK (true);
CREATE POLICY "Authenticated users can update veiculos" ON public.veiculos FOR UPDATE TO authenticated USING (true);
CREATE POLICY "Authenticated users can delete veiculos" ON public.veiculos FOR DELETE TO authenticated USING (true);

CREATE POLICY "Authenticated users can view morador_lote" ON public.morador_lote FOR SELECT TO authenticated USING (true);
CREATE POLICY "Authenticated users can insert morador_lote" ON public.morador_lote FOR INSERT TO authenticated WITH CHECK (true);
CREATE POLICY "Authenticated users can update morador_lote" ON public.morador_lote FOR UPDATE TO authenticated USING (true);
CREATE POLICY "Authenticated users can delete morador_lote" ON public.morador_lote FOR DELETE TO authenticated USING (true);

CREATE POLICY "Authenticated users can view morador_veiculo" ON public.morador_veiculo FOR SELECT TO authenticated USING (true);
CREATE POLICY "Authenticated users can insert morador_veiculo" ON public.morador_veiculo FOR INSERT TO authenticated WITH CHECK (true);
CREATE POLICY "Authenticated users can update morador_veiculo" ON public.morador_veiculo FOR UPDATE TO authenticated USING (true);
CREATE POLICY "Authenticated users can delete morador_veiculo" ON public.morador_veiculo FOR DELETE TO authenticated USING (true);

CREATE POLICY "Authenticated users can view visitantes" ON public.visitantes FOR SELECT TO authenticated USING (true);
CREATE POLICY "Authenticated users can insert visitantes" ON public.visitantes FOR INSERT TO authenticated WITH CHECK (true);
CREATE POLICY "Authenticated users can update visitantes" ON public.visitantes FOR UPDATE TO authenticated USING (true);
CREATE POLICY "Authenticated users can delete visitantes" ON public.visitantes FOR DELETE TO authenticated USING (true);
