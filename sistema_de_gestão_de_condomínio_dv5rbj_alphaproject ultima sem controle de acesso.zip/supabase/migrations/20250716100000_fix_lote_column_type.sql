/*
# [Operation Name]
Fix Lote Column Type and Handle Data Inconsistencies

## Query Description: [This operation ensures the 'lotes' table can store alphanumeric lot numbers (like 'LT24') by changing the 'numero' column type to TEXT. This is a non-destructive change and should not result in data loss for existing text-based data. It is a necessary fix to allow correct data importation from the provided spreadsheet.]

## Metadata:
- Schema-Category: ["Structural"]
- Impact-Level: ["Low"]
- Requires-Backup: [false]
- Reversible: [true]

## Structure Details:
- Table: lotes
- Column: numero
- Change: Data type changed from any other type to TEXT.

## Security Implications:
- RLS Status: [Enabled]
- Policy Changes: [No]
- Auth Requirements: [None]

## Performance Impact:
- Indexes: [No change to indexes]
- Triggers: [No change]
- Estimated Impact: [Negligible performance impact.]
*/
ALTER TABLE public.lotes
ALTER COLUMN numero TYPE TEXT;
