/*
# Sistema de Gestão de Condomínio - Schema Inicial
Criação das tabelas principais para gestão de condomínio horizontal

## Query Description: 
Esta migração criará todas as tabelas necessárias para o sistema de gestão de condomínio.
Inclui estruturas para empreendimentos, lotes, moradores, veículos e visitantes.
Operação segura que não afeta dados existentes.

## Metadata:
- Schema-Category: "Structural"
- Impact-Level: "Low"
- Requires-Backup: false
- Reversible: true

## Structure Details:
- Tabelas: empreendimentos, lotes, moradores, veiculos, visitantes, morador_lote, morador_veiculo
- Colunas: campos específicos para cada entidade
- Constraints: chaves primárias, estrangeiras e validações

## Security Implications:
- RLS Status: Enabled para todas as tabelas
- Policy Changes: Yes
- Auth Requirements: Usuários autenticados

## Performance Impact:
- Indexes: Adicionados indexes básicos
- Triggers: Nenhum trigger inicial
- Estimated Impact: Mínimo - apenas criação de estruturas
*/

-- Enable RLS
ALTER DATABASE postgres SET "app.jwt_secret" TO 'your-jwt-secret';

-- Tabela de empreendimentos
CREATE TABLE IF NOT EXISTS empreendimentos (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    nome VARCHAR(255) NOT NULL,
    endereco TEXT,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Tabela de lotes
CREATE TABLE IF NOT EXISTS lotes (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    empreendimento_id UUID REFERENCES empreendimentos(id),
    quadra VARCHAR(50) NOT NULL,
    numero VARCHAR(50) NOT NULL,
    area_privativa DECIMAL(10,2),
    status VARCHAR(50) CHECK (status IN ('vazio', 'obra', 'casa')) DEFAULT 'vazio',
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    UNIQUE(empreendimento_id, quadra, numero)
);

-- Tabela de moradores
CREATE TABLE IF NOT EXISTS moradores (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    nome VARCHAR(255) NOT NULL,
    cpf VARCHAR(14) UNIQUE,
    identidade VARCHAR(20),
    telefone VARCHAR(20),
    celular VARCHAR(20),
    email VARCHAR(255),
    cliente_status VARCHAR(50) CHECK (cliente_status IN ('Proprietário', 'Inquilino', 'Proprietário Morador', 'Dependente')) NOT NULL,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Tabela de associação morador-lote
CREATE TABLE IF NOT EXISTS morador_lote (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    morador_id UUID REFERENCES moradores(id) ON DELETE CASCADE,
    lote_id UUID REFERENCES lotes(id) ON DELETE CASCADE,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    UNIQUE(morador_id, lote_id)
);

-- Tabela de veículos
CREATE TABLE IF NOT EXISTS veiculos (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    marca VARCHAR(100),
    modelo VARCHAR(100),
    cor VARCHAR(50),
    placa VARCHAR(10) UNIQUE NOT NULL,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Tabela de associação morador-veículo
CREATE TABLE IF NOT EXISTS morador_veiculo (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    morador_id UUID REFERENCES moradores(id) ON DELETE CASCADE,
    veiculo_id UUID REFERENCES veiculos(id) ON DELETE CASCADE,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    UNIQUE(morador_id, veiculo_id)
);

-- Tabela de visitantes
CREATE TABLE IF NOT EXISTS visitantes (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    nome VARCHAR(255) NOT NULL,
    documento VARCHAR(20) NOT NULL, -- CPF ou RG
    tipo_documento VARCHAR(10) CHECK (tipo_documento IN ('CPF', 'RG')) NOT NULL,
    telefone VARCHAR(20),
    classificacao VARCHAR(50) CHECK (classificacao IN ('Visitante', 'Entregador', 'Prestador de serviço', 'Corretor de imóveis', 'Outros')) NOT NULL,
    autorizado BOOLEAN DEFAULT FALSE,
    creci VARCHAR(20), -- Para corretores
    tipo_servico VARCHAR(100), -- Para prestadores de serviço
    lote_id UUID REFERENCES lotes(id),
    veiculo VARCHAR(100), -- Descrição do veículo
    veiculo_cor VARCHAR(50),
    veiculo_placa VARCHAR(10),
    data_entrada TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    data_saida TIMESTAMP WITH TIME ZONE,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Indexes para performance
CREATE INDEX IF NOT EXISTS idx_lotes_empreendimento ON lotes(empreendimento_id);
CREATE INDEX IF NOT EXISTS idx_lotes_quadra_numero ON lotes(quadra, numero);
CREATE INDEX IF NOT EXISTS idx_moradores_cpf ON moradores(cpf);
CREATE INDEX IF NOT EXISTS idx_moradores_nome ON moradores(nome);
CREATE INDEX IF NOT EXISTS idx_veiculos_placa ON veiculos(placa);
CREATE INDEX IF NOT EXISTS idx_visitantes_lote ON visitantes(lote_id);
CREATE INDEX IF NOT EXISTS idx_visitantes_data_entrada ON visitantes(data_entrada);
CREATE INDEX IF NOT EXISTS idx_visitantes_data_saida ON visitantes(data_saida);

-- Enable RLS em todas as tabelas
ALTER TABLE empreendimentos ENABLE ROW LEVEL SECURITY;
ALTER TABLE lotes ENABLE ROW LEVEL SECURITY;
ALTER TABLE moradores ENABLE ROW LEVEL SECURITY;
ALTER TABLE morador_lote ENABLE ROW LEVEL SECURITY;
ALTER TABLE veiculos ENABLE ROW LEVEL SECURITY;
ALTER TABLE morador_veiculo ENABLE ROW LEVEL SECURITY;
ALTER TABLE visitantes ENABLE ROW LEVEL SECURITY;

-- Políticas RLS básicas (permitir tudo para usuários autenticados)
CREATE POLICY "Users can access empreendimentos" ON empreendimentos FOR ALL USING (auth.role() = 'authenticated');
CREATE POLICY "Users can access lotes" ON lotes FOR ALL USING (auth.role() = 'authenticated');
CREATE POLICY "Users can access moradores" ON moradores FOR ALL USING (auth.role() = 'authenticated');
CREATE POLICY "Users can access morador_lote" ON morador_lote FOR ALL USING (auth.role() = 'authenticated');
CREATE POLICY "Users can access veiculos" ON veiculos FOR ALL USING (auth.role() = 'authenticated');
CREATE POLICY "Users can access morador_veiculo" ON morador_veiculo FOR ALL USING (auth.role() = 'authenticated');
CREATE POLICY "Users can access visitantes" ON visitantes FOR ALL USING (auth.role() = 'authenticated');
